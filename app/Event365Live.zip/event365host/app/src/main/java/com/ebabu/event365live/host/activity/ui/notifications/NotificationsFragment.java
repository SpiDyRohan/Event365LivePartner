package com.ebabu.event365live.host.activity.ui.notifications;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.activity.NotificationActivity;
import com.ebabu.event365live.host.activity.ui.EventActivity;
import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.databinding.FragmentNotificationsBinding;
import com.ebabu.event365live.host.events.CheckedInEvent;
import com.ebabu.event365live.host.fragments.PastEventFragment;
import com.ebabu.event365live.host.fragments.UpcomingEventFragment;
import com.ebabu.event365live.host.utils.Utility;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;


public class NotificationsFragment extends Fragment {


    FragmentNotificationsBinding binding;
    public ViewPager myViewPager;
    public ImageView createEventImg;
    String name;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding= DataBindingUtil.
        inflate(inflater, R.layout.fragment_notifications, container, false);
        createEventImg=binding.imageView24;
        binding.notificationImg.setVisibility(View.GONE);
        myViewPager=binding.myViewPager;

        binding.searchEt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_SEARCH)) ||
                        (actionId == EditorInfo.IME_ACTION_SEARCH)) {

                    InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(binding.getRoot().getWindowToken(), 0);

                    if (!name.equals(binding.searchEt.getText().toString().trim())) {
                        name = binding.searchEt.getText().toString().trim();
                        EventBus.getDefault().post(new CheckedInEvent(name));
                    }

                }
                return false;
            }
        });

        if(!Utility.getSharedPreferencesBoolean(getContext(), API.IS_CREATE_EVENT))
            createEventImg.setVisibility(View.INVISIBLE);


        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new UpcomingEventFragment(), getString(R.string.upcoming_events));
        adapter.addFragment(new PastEventFragment(), getString(R.string.past_events));
        binding.myViewPager.setAdapter(adapter);

        binding.tabs.setupWithViewPager(binding.myViewPager);

        binding.backArrow.setOnClickListener(v-> getActivity().onBackPressed());

        //create event
        binding.imageView24.setOnClickListener(v-> startActivity(new Intent(getActivity(), EventActivity.class)));
        binding.imageView7.setOnClickListener(v-> startActivity(new Intent(getActivity(), NotificationActivity.class)));

        return binding.getRoot();
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }
        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.searchEt.setText("");
        name="";
    }
}