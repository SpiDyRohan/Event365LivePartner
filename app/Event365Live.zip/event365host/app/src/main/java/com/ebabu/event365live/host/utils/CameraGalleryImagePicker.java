package com.ebabu.event365live.host.utils;

import android.content.Context;

public class CameraGalleryImagePicker {

    private static CameraGalleryImagePicker mInstance;
    private static Context mContext;
    private final int STORAGE_REQUEST_CODE=101;


    private CameraGalleryImagePicker(){}

    public static CameraGalleryImagePicker getInstance(Context context){
       mContext=context;
       return (mInstance==null) ? mInstance = new CameraGalleryImagePicker() : mInstance;
    }
}
