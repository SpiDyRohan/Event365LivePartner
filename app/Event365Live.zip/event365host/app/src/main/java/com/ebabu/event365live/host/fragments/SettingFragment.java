package com.ebabu.event365live.host.fragments;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.activity.ContactUs;
import com.ebabu.event365live.host.activity.ManageUser;
import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.bankdetails.WithdrawActivity;
import com.ebabu.event365live.host.databinding.FragmentSettingBinding;
import com.ebabu.event365live.host.utils.Utility;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.jakewharton.rxbinding2.view.RxView;

import java.util.concurrent.TimeUnit;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public class SettingFragment extends Fragment {

    FragmentSettingBinding binding;
    Disposable disposable;
    public TextView managedUserTv;
    public View lineView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_setting, container, false);
        managedUserTv = binding.textView22;
        lineView = binding.view5;

        if (!Utility.getSharedPreferencesBoolean(getContext(), API.IS_MANAGE_USER)) {
            managedUserTv.setVisibility(View.GONE);
            binding.view5.setVisibility(View.GONE);
        }

        binding.getPaidTv.setOnClickListener(v ->{
            startActivityForResult(
                    new Intent(getActivity(), WithdrawActivity.class),4001);
                });





        binding.switch1.setChecked(!Utility.getSharedPreferencesBoolean(getContext(), API.NOTIFICATION_CLOSED));
        binding.textView22.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), ManageUser.class));
        });

        binding.logoutTv.setOnClickListener(v ->
                new MaterialAlertDialogBuilder(getContext())
                        .setTitle(getString(R.string.alert))
                        .setMessage(getString(R.string.really_want_logout))
                        .setPositiveButton("Yes", (dialogInterface, i) -> Utility.logOut(getContext()))
                        .setNegativeButton("Cancel", null)
                        .show()
        );

        binding.backArrow.setOnClickListener(v -> getActivity().onBackPressed());
        binding.privacyPolicy.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy_url)));
            startActivity(browserIntent);
        });

        binding.faqs.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.faq_url)));
            startActivity(browserIntent);
        });

        binding.termAndCondition.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.terms_and_condition_url)));
            startActivity(browserIntent);
        });

        binding.shareBtn.setOnClickListener(v -> Utility.inviteFriend(getContext(), "Please connect with Event365Live app, Available on playstore!"));
        binding.helpBtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), ContactUs.class)));

        disposable = RxView.clicks(binding.switch1).throttleFirst(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread()).
                        subscribe(o -> Utility.setSharedPreferencesBoolean(getContext(), API.NOTIFICATION_CLOSED, !binding.switch1.isChecked()));

        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        disposable.dispose();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
