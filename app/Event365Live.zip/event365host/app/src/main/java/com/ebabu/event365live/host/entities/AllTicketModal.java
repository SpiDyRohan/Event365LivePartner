package com.ebabu.event365live.host.entities;

public class AllTicketModal {
    private String ticketName;
    private String ticketPrice;
    private String ticketQuantity;
    private String ticketDes;


}
