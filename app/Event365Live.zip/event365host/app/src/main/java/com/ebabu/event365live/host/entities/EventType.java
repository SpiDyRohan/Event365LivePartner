package com.ebabu.event365live.host.entities;

public enum  EventType {
    UPCOMING,PAST,HOME
}
