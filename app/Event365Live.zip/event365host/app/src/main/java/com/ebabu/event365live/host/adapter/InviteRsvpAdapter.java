package com.ebabu.event365live.host.adapter;

import android.app.Application;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.request.RequestOptions;
import com.ebabu.event365live.host.DI.App;
import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.entities.UserDAO;
import com.ebabu.event365live.host.utils.DrawableUtils;

import org.w3c.dom.Text;

import java.util.List;
import java.util.concurrent.Callable;

import javax.inject.Inject;
import javax.inject.Singleton;

import dagger.Provides;
import de.hdodenhof.circleimageview.CircleImageView;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class InviteRsvpAdapter extends RecyclerView.Adapter<InviteRsvpAdapter.InviteRsvpHolder>{


    @Inject
    RequestManager requestManager;

    List<UserDAO> list;

    public InviteRsvpAdapter(){

        App.getAppComponent().inject(this);
    }

    @NonNull
    @Override
    public InviteRsvpHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.invite_rsvp_custom_layout,parent,false);
        return new InviteRsvpHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InviteRsvpHolder holder, int position) {

        UserDAO dao=list.get(position);
        holder.nameTv.setText(dao.getName());
        if(dao.getProfilePic()!=null && dao.getProfilePic().length()>10) {
            requestManager.load(dao.getProfilePic()).into(holder.imageView);
            holder.thumbTv.setText("");
        }
        else{
            requestManager.load(R.mipmap.circle_color_icon).into(holder.imageView);
            holder.thumbTv.setText(String.valueOf(dao.getName().charAt(0)).toUpperCase());
        }

        holder.checkBox.setChecked(dao.isChecked());

        holder.checkBox.setOnClickListener(v->list.get(position).setChecked(holder.checkBox.isChecked()));

    }

    @Override
    public int getItemCount() {
        return list==null?0:list.size();
    }

    class InviteRsvpHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView nameTv,thumbTv;
        CheckBox checkBox;
        InviteRsvpHolder(@NonNull View itemView){
            super(itemView);
            imageView=itemView.findViewById(R.id.img);
            nameTv=itemView.findViewById(R.id.name_tv);
            thumbTv=itemView.findViewById(R.id.thumb_tv);
            checkBox=itemView.findViewById(R.id.checkbox);
        }
    }

    public void refresh(List<UserDAO> list){
        this.list=list;
        notifyDataSetChanged();
    }
}
