package com.ebabu.event365live.host.repositories;

import androidx.lifecycle.MutableLiveData;

import com.ebabu.event365live.host.api.ApiInterface;
import com.ebabu.event365live.host.entities.UserResponse;
import com.google.gson.JsonObject;

public class CustomerRepository {

    private static CustomerRepository mInstance;

    private CustomerRepository() {
    }

    public static CustomerRepository getInstance(){
        return mInstance==null? mInstance=new CustomerRepository() : mInstance;
    }


}
