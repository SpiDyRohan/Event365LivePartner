package com.ebabu.event365live.host.bouncerecycler;

public interface SpringSystemListener {
    void onBeforeIntegrate(BaseSpringSystem var1);

    void onAfterIntegrate(BaseSpringSystem var1);
}
