package com.ebabu.event365live.host.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.ebabu.event365live.host.BaseActivity;
import com.ebabu.event365live.host.DI.App;
import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.api.ApiInterface;
import com.ebabu.event365live.host.databinding.ActivityResetPasswordBinding;
import com.ebabu.event365live.host.events.FailureEvent;
import com.ebabu.event365live.host.utils.Constants;
import com.ebabu.event365live.host.utils.Dialogs;
import com.ebabu.event365live.host.utils.MyLoader;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResetPassword extends BaseActivity {

    ActivityResetPasswordBinding binding;
    String pwd="",confPwd="";
    boolean isValid;
    int id;
    String mail;

    /* regex to match atleast one digit or one character*/
    private static final String regex=".*[a-zA-Z\\d].*";

    @Inject
    ApiInterface apiInterface;

    MyLoader loader;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding= DataBindingUtil.setContentView(this,R.layout.activity_reset_password);
        App.getAppComponent().inject(this);

        loader=new MyLoader(this);
        id=getIntent().getIntExtra(API.ID,-1);
        mail=getIntent().getStringExtra(API.EMAIL);
        Log.e("Reset Password","ID : "+id);

        binding.pwdEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                confPwd=binding.pwdEt.getText().toString();
                if(confPwd.length()>5 && pwd.length()>5) validate();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        binding.mailEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                pwd=binding.mailEt.getText().toString();
                if(confPwd.length()>5 && pwd.length()>5) validate();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        binding.createAccBtn.setOnClickListener(v->{
            if (!isValid && pwd.length()<6){
                Dialogs.toast(getApplicationContext(),v,getString(R.string.password_length_err));
                return;
            }

            if(!pwd.matches(regex)){
                Dialogs.toast(getApplicationContext(),v,"Password must contain atleast one digit or alphabet!");
                return;
            }

            else if(isValid) {

                loader.show("");

                JsonObject jsonObject=new JsonObject();
                jsonObject.addProperty(API.ID,id);
                if(mail!=null)
                    jsonObject.addProperty(API.EMAIL,mail);
                jsonObject.addProperty(API.NEW_PASSWORD,pwd);
                Call<JsonElement> call=apiInterface.resetPassword(jsonObject);
                call.enqueue(new Callback<JsonElement>() {
                    @Override
                    public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                        loader.dismiss();
                        if(response.isSuccessful()){

                            try {
                                JSONObject OBJ = new JSONObject(response.body().toString());
                                Toast.makeText(getApplicationContext(),OBJ.getString(API.MESSAGE),Toast.LENGTH_LONG).show();
                                // TODO: 10/10/19
                                Intent intent=new Intent(ResetPassword.this,Login.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);

                            } catch (JSONException e) {
                                Dialogs.toast(getApplicationContext(),v,getString(R.string.something_went_wrong));
                            }
                        }
                        else{
                            try {
                                JSONObject OBJ = new JSONObject(response.errorBody().string());
                                Dialogs.toast(getApplicationContext(),v,OBJ.getString(API.MESSAGE));
                            }catch (Exception e){
                                Dialogs.toast(getApplicationContext(),v,getString(R.string.something_went_wrong));
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonElement> call, Throwable t) {
                        Dialogs.toast(getApplicationContext(),v,getString(R.string.something_went_wrong));
                    }
                });
            }

            else
                Dialogs.toast(getApplicationContext(),v,getString(R.string.pwd_not_matched));
        });


        binding.backArrow.setOnClickListener(v->onBackPressed());

    }

    private void validate(){
        if (confPwd.equals(pwd)) {
            isValid=true;
            binding.pwdImg.setVisibility(View.VISIBLE);
            binding.validMailImg.setVisibility(View.VISIBLE);
        }
        else{
            isValid=false;
            binding.pwdImg.setVisibility(View.INVISIBLE);
            binding.validMailImg.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onNetworkChanged(boolean isConnected) {
        runOnUiThread(()->{
            if(isConnected)
                findViewById(R.id.no_internet_layout).setVisibility(View.GONE);
            else
                findViewById(R.id.no_internet_layout).setVisibility(View.VISIBLE);
        });
    }
}
