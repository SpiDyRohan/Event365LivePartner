package com.ebabu.event365live.host.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;

import com.ebabu.event365live.host.R;

public class ViewAllRSVPAdapter extends PagerAdapter {

    private Context context;
    private String[] rsvpCategoryName = {"All","Free RSVp","Paid RSVP","VIP RSVP","Pending"};

    public ViewAllRSVPAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return rsvpCategoryName.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return object == view;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View view = LayoutInflater.from(context).inflate(R.layout.view_all_rsvp_layout,container,false);
        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        container.removeView((View) object);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return rsvpCategoryName[position];
    }
}
