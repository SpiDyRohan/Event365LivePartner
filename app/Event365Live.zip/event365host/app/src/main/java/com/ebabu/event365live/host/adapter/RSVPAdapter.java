package com.ebabu.event365live.host.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.entities.UserDAO;

import java.util.List;

public class RSVPAdapter extends RecyclerView.Adapter<RSVPAdapter.MyViewHolder> {

    List<UserDAO> list;
    UserClickListener userClickListener;

    public RSVPAdapter(UserClickListener userClickListener) {
        this.userClickListener = userClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.laout_rsvp_list,parent,false);
        return  new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {



        UserDAO dao=list.get(position);
        holder.nameTv.setText(dao.getName());
        holder.typeTv.setText(dao.getUserType());
        char ch=dao.getName().charAt(0);

        StringBuilder thumbTitle=new StringBuilder(String.valueOf(ch).toUpperCase());

        String []nameArr=dao.getName().split(" ");

        if(nameArr.length>1) {
            thumbTitle.append(nameArr[1].charAt(0));
        }

        holder.titleThumb.setText(thumbTitle.toString().toUpperCase());
    }

    @Override
    public int getItemCount() {
        return list==null?0:list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameTv,typeTv,titleThumb;
        ImageView img;
        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);
            nameTv=itemView.findViewById(R.id.name_tv);
            typeTv=itemView.findViewById(R.id.type_tv);
            titleThumb=itemView.findViewById(R.id.title_thumb);
            img=itemView.findViewById(R.id.img);
        }
    }

    public void refresh(List<UserDAO> list){
        this.list=list;
        notifyDataSetChanged();
    }

    public void remove(UserDAO dao){
        list.remove(dao);
        notifyDataSetChanged();
    }

    public interface UserClickListener{
        void clickedUser(UserDAO userDAO);
    }
}
