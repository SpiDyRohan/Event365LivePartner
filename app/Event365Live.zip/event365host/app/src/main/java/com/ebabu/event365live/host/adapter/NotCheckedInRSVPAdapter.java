package com.ebabu.event365live.host.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ebabu.event365live.host.R;

public class NotCheckedInRSVPAdapter extends RecyclerView.Adapter<NotCheckedInRSVPAdapter.NotCheckedInHolder>{

    private Context context;

    public NotCheckedInRSVPAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public NotCheckedInHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.checked_in_rsvp_layout,parent,false);
        return new NotCheckedInHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotCheckedInHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 20;
    }

    class NotCheckedInHolder extends RecyclerView.ViewHolder {
        public NotCheckedInHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
