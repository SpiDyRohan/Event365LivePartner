package com.ebabu.event365live.host.fragments;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;

import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.activity.MyVenues;
import com.ebabu.event365live.host.activity.ProfileActivity;
import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.databinding.FragmentProfileBinding;
import com.ebabu.event365live.host.entities.FreeTicketDao;
import com.ebabu.event365live.host.utils.Utility;

public class ProfileFragment extends Fragment {

    FragmentProfileBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding= DataBindingUtil.inflate(inflater,R.layout.fragment_profile, container, false);

/*        Window window = getActivity().getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(getContext(),R.color.whiteLight));*/

        binding.profileSettings.setOnClickListener(v->startActivity(new Intent(getActivity(), ProfileActivity.class)));
        binding.venueLocation.setOnClickListener(v->startActivity(new Intent(getActivity(), MyVenues.class)));

        return binding.getRoot();
    }

}
