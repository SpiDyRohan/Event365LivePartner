package com.ebabu.event365live.host.payment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.stripe.android.PaymentSession;
import com.stripe.android.PaymentSessionConfig;
import com.stripe.android.PaymentSessionData;
import com.stripe.android.model.PaymentMethod;
import com.stripe.android.model.ShippingInformation;

public class HostActivity extends Activity {
    private PaymentSession paymentSession;
    private Button startPaymentFlowButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* paymentSession = new PaymentSession(
                this,
                new PaymentSessionConfig().Builder()
                        .setPrepopulatedShippingInfo(getDefaultShippingInfo())
                        .build()
        );*/
        setupPaymentSession();
    }

    private void setupPaymentSession() {
        paymentSession.init(
                new PaymentSession.PaymentSessionListener() {
                    @Override
                    public void onCommunicatingStateChanged(
                            boolean isCommunicating
                    ) {
                        // update UI, such as hiding or showing a progress bar
                    }

                    @Override
                    public void onError(
                            int errorCode,
                            @Nullable String errorMessage
                    ) {
                        // handle error
                    }

                    @Override
                    public void onPaymentSessionDataChanged(
                            @NonNull PaymentSessionData data
                    ) {
                        final PaymentMethod paymentMethod = data.getPaymentMethod();
                        // use paymentMethod
                    }
                }
        );
        startPaymentFlowButton.setEnabled(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            paymentSession.handlePaymentData(requestCode, resultCode, data);
        }
    }

    @NonNull
    private ShippingInformation getDefaultShippingInfo() {
        // optionally specify default shipping address
        return new ShippingInformation();
    }
}
