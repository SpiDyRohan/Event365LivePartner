package com.ebabu.event365live.host.entities;

import java.io.Serializable;
import java.util.List;

public class VenueImages implements Serializable {

    private List<String> venueImages;

    public List<String> getVenueImages() {
        return venueImages;
    }

    public void setVenueImages(List<String> venueImages) {
        this.venueImages = venueImages;
    }

    @Override
    public String toString() {
        return "VenueImages{" +
                "venueImages='" + venueImages + '\'' +
                '}';
    }
}
