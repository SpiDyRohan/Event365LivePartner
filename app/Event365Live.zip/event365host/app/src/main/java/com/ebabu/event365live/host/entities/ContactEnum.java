package com.ebabu.event365live.host.entities;

public enum ContactEnum{
    in_app_only,phone_calls,email
}
