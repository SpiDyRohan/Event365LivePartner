package com.ebabu.event365live.host.fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.ebabu.event365live.host.DI.App;
import com.ebabu.event365live.host.R;
import com.ebabu.event365live.host.activity.MyVenues;
import com.ebabu.event365live.host.adapter.GalleryPicAdapter;
import com.ebabu.event365live.host.adapter.VenuePicInEventAdapter;
import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.api.ApiInterface;
import com.ebabu.event365live.host.databinding.FragmentCreateEventBinding;
import com.ebabu.event365live.host.databinding.LayoutPostEventDialogBinding;
import com.ebabu.event365live.host.entities.CreateEventDAO;
import com.ebabu.event365live.host.entities.EventImages;
import com.ebabu.event365live.host.entities.FreeTicketDao;
import com.ebabu.event365live.host.entities.HostDetailResponse;
import com.ebabu.event365live.host.entities.ImageDAO;
import com.ebabu.event365live.host.entities.RSVPTicketDao;
import com.ebabu.event365live.host.entities.SubVenue;
import com.ebabu.event365live.host.entities.SubVenueDao;
import com.ebabu.event365live.host.entities.TableAndSeatingDao;
import com.ebabu.event365live.host.entities.UpdateEventDao;
import com.ebabu.event365live.host.entities.VenueDAO;
import com.ebabu.event365live.host.utils.Constants;
import com.ebabu.event365live.host.utils.Dialogs;
import com.ebabu.event365live.host.utils.FileUtils;
import com.ebabu.event365live.host.utils.MyLoader;
import com.ebabu.event365live.host.utils.PermissionUtils;
import com.ebabu.event365live.host.utils.StringUtils;
import com.ebabu.event365live.host.utils.Utility;
import com.ebabu.event365live.host.viewmodels.CreateEventViewModel;
import com.ebabu.event365live.host.viewmodels.VenueViewModel;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jakewharton.rxbinding2.widget.RxTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;

import io.reactivex.disposables.CompositeDisposable;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class CreateEventFragment extends Fragment {

    private static final int RC_HANDLE_CAMERA_PERM = 101;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 606;
    private static final int PLACE_PICKER_REQUEST_CODE = 607;
    private static String eventOccuranceType;
    final int[] oldPos = new int[1];
    final int[] newPos = new int[1];
    private final String deletedIds = "";
    @Inject
    RequestManager requestManager;
    MyLoader loader;
    List<String> deleteVenueImgList;
    UpdateEventDao updateEventDao;
    String venueName, venueAddress;
    String startDate, endDate, startTime, endTime, startSellingDate, endSellingDate, startSellingTime, endSellingTime, sortDescription;
    StringBuilder deletedPreviousImagesIds;
    @Inject
    ApiInterface apiInterface;
    private ArrayList<String> imageList = new ArrayList<>();
    private Activity activity;
    private LatLng latLongt;
    private List<ImageDAO> imageDaoList;

    private FragmentCreateEventBinding binding;
    private CreateEventViewModel viewModel;
    private VenueViewModel venueViewModel;
    private boolean mLocationPermissionGranted;
    private String currentPhotoPath;
    private CreateEventDAO createEventDAO;

    private StringBuilder selection;
    private String eventType = "";
    private boolean isVenuer;
    private VenueDAO selectedVenue;
    private VenuePicInEventAdapter venuePicInEventAdapter;
    private GalleryPicAdapter galleryPicAdapter;
    private String startEventDateFromApi, selectedStartEventDate = "";

    private Context mContext;
    private PermissionUtils permissionUtils;

    private boolean isValid;
    private CompositeDisposable disposable;
    private boolean isEventDetailValid, isAdditionInfoValid;
    private boolean update;
    private AlertDialog alertDialog;
    private LayoutPostEventDialogBinding eventDialogBinding;
    private SimpleDateFormat isoSDF;
    private List<ImageDAO> previousImages;
    private List<SubVenueDao> updateSelectedSubVenues = new ArrayList<>();
    // ImageView Drag & Drop
    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(ItemTouchHelper.START | ItemTouchHelper.END, 0) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            oldPos[0] = viewHolder.getAdapterPosition();
            newPos[0] = target.getAdapterPosition();
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

        }

        @Override
        public void clearView(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
            super.clearView(recyclerView, viewHolder);
            moveItem(oldPos[0], newPos[0]);
        }
    };
    private String getTodayDate = "";


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (Activity) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        update = getArguments().getBoolean("update");
        loader = new MyLoader(getContext());
    }

    @SuppressLint("FragmentLiveDataObserve")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_create_event, container, false);
        viewModel = ViewModelProviders.of(this).get(CreateEventViewModel.class);
        App.getAppComponent().inject(this);
        mContext = container.getContext();
        disposable = new CompositeDisposable();
        binding.setViewmodel(viewModel);
        binding.backArrow.setOnClickListener(v -> getActivity().onBackPressed());
        previousImages = new ArrayList<>();
        selection = new StringBuilder();
        setGalleryAdapter();
        Date today = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
        //SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
        getTodayDate = df.format(today);
        if (update) {
            loader.show("");
            deleteVenueImgList = new ArrayList<>();
            deletedPreviousImagesIds = new StringBuilder();
            binding.textView20.setText("Edit Event");
            binding.sellSwitch.setVisibility(View.INVISIBLE);

            viewModel.getEditEventDetails(getArguments().getInt("id")).observe(getViewLifecycleOwner(),
                    userResponse -> {
                        loader.dismiss();
                        if (userResponse.getCode() == API.SESSION_EXPIRE) {
                            userResponse.setCode(0);
                            Utility.sessionExpired(getContext());
                        } else if (!userResponse.isSuccess()) {
                            loader.dismiss();
                            Toast.makeText(getContext(), getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show();
                        } else {
                            updateEventDao = userResponse.getUpdateEventDao();
                            setViewData();
//                            if (isVenuer)
                            fetchVenueImages();
                        }
                    }
            );
        } else {
            binding.sellSwitch.setVisibility(View.VISIBLE);
            createEventDAO = CreateEventFragmentArgs.fromBundle(getArguments()).getEventDAO();
            binding.textView20.setText("Create an Event");
            if (createEventDAO.getOccorredOnDays() != null) {
                List<String> days = Arrays.asList(createEventDAO.getOccorredOnDays().split(", "));
                ChipGroup cg;
                int type;

                if (createEventDAO.getEventOccuranceType().equalsIgnoreCase("monthly")) {
                    cg = binding.monthChipGroup;
                    type = 2;
                } else {
                    cg = binding.daysChipGroup;
                    type = 1;
                }

                for (int i = 0; i < cg.getChildCount(); i++) {
                    Chip chip = (Chip) cg.getChildAt(i);

                    if (days.contains(chip.getText().toString())) {
                        chip.setChecked(true);
                        if (type == 1)
                            viewModel.selectDays(chip);
                        else viewModel.selectMonths(chip);
                    }
                }
            }
            if (createEventDAO.getStartDate() != null) {
                binding.endDateTv.setText(createEventDAO.getEndDate());
                binding.endTimeTv.setText(createEventDAO.getEndTime());
                binding.startTimeTv.setText(createEventDAO.getStartTime());
                binding.textView39.setText(createEventDAO.getStartDate());
            }

            try {

                binding.eventNameEt.setText(createEventDAO.getName());
                binding.venueNameEt.setText(createEventDAO.getVenueName());
                binding.venueLocEt.setText(createEventDAO.getVenueName());
                binding.additionEt.setText(createEventDAO.getDesc());
                binding.additionEt2.setText(createEventDAO.getDesc2());

                latLongt = new LatLng(Double.parseDouble(createEventDAO.getLat()), Double.parseDouble(createEventDAO.getLongt()));

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        binding.textView23.setVisibility(View.GONE);
        binding.contactChipGroup.setVisibility(View.GONE);
        binding.view19.setVisibility(View.GONE);

        eventType = "Free";

//code we require
        disposable.add(
                RxTextView.textChanges(binding.additionEt)
                        .subscribe(charSequence -> {
                            if (charSequence.length() >= 200) {
                                if (!isEventDetailValid) {
                                    isEventDetailValid = true;
                                    binding.additionEtImg.setVisibility(View.VISIBLE);
                                }
                            } else {
                                if (isEventDetailValid) {
                                    isEventDetailValid = false;
                                    binding.additionEtImg.setVisibility(View.INVISIBLE);
                                }
                            }
                        }));

//code we require
        disposable.add(
                RxTextView.textChanges(binding.additionEt2)
                        .subscribe(charSequence -> {
                            if (charSequence.length() >= 200) {
                                if (!isAdditionInfoValid) {
                                    isAdditionInfoValid = true;
                                    binding.additionEt2Img.setVisibility(View.VISIBLE);
                                }
                            } else {
                                if (isAdditionInfoValid) {
                                    isAdditionInfoValid = false;
                                    binding.additionEt2Img.setVisibility(View.INVISIBLE);
                                }
                            }
                        }));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(mContext,
                R.array.event_array, R.layout.my_spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        binding.typeSpinner.setAdapter(adapter);

        if (update)
            binding.typeSpinner.setEnabled(false);
        else
            binding.typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    viewModel.reset(l);
                    if (l == 0) {
                        eventOccuranceType = "oneTime";
                        binding.typeSubLayout.setVisibility(View.GONE);
                        binding.typeSubLayout.setVisibility(View.GONE);
                        binding.typeSubLayout.setVisibility(View.GONE);
                    } else if (l == 2 || l == 3 || l == 1) {
                        binding.typeSubLayout.setVisibility(View.VISIBLE);
                        binding.typeSubLayout.setVisibility(View.VISIBLE);
                        binding.typeSubLayout.setVisibility(View.VISIBLE);
                        if (l == 3) {
                            if (binding.monthChipGroup.getChildCount() == 0) {
                                for (int index = 0; index < 31; index++) {
                                    Chip chip = new Chip(mContext);
                                    chip.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                                    chip.setCheckable(true);
                                    chip.setCheckedIconVisible(true);
                                    chip.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
                                    chip.setCheckedIcon(mContext.getResources().getDrawable(R.drawable.tick));
                                    chip.setChipIcon(mContext.getResources().getDrawable(R.drawable.tick_unchecked));
                                    chip.setText(String.valueOf(index + 1));

                                    chip.setOnCheckedChangeListener((compoundButton, b) -> {
                                        viewModel.selectMonths(chip);
                                    });

                                    binding.monthChipGroup.addView(chip);
                                }
                            }
                            eventOccuranceType = "monthly";
                            binding.monthScrollView.setVisibility(View.VISIBLE);
                            binding.daysDaysScrollView.setVisibility(View.GONE);
                        } else {
                            if (l == 1) {
                                eventOccuranceType = "daily";
                                binding.daysChipGroup.setSingleSelection(false);
                            } else {
                                binding.daysChipGroup.setSingleSelection(true);
                                eventOccuranceType = "weekly";
                            }
                            binding.daysDaysScrollView.setVisibility(View.VISIBLE);
                            binding.monthScrollView.setVisibility(View.GONE);
                            if (binding.daysChipGroup.getChildCount() == 0) {
                                for (int index = 0; index < 7; index++) {
                                    Chip chip = new Chip(mContext);
                                    chip.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                                    chip.setCheckable(true);
                                    chip.setCheckedIconVisible(true);
                                    chip.setBackgroundColor(mContext.getResources().getColor(R.color.transparent));
                                    chip.setCheckedIcon(mContext.getResources().getDrawable(R.drawable.tick));
                                    chip.setChipIcon(mContext.getResources().getDrawable(R.drawable.tick_unchecked));
                                    chip.setText(Constants.days[index]);
                                    chip.setOnCheckedChangeListener((compoundButton, b) -> {
                                        viewModel.selectDays(chip);
                                    });

                                    binding.daysChipGroup.addView(chip);
                                }
                            }
                        }
                    }

                    createEventDAO.setEventOccuranceType(eventOccuranceType);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });


        if (createEventDAO != null) {
            if (createEventDAO.getImageDAOList() != null)
                imageDaoList = createEventDAO.getImageDAOList();
            else
                imageDaoList = new ArrayList<>();

            galleryPicAdapter.refresh(imageDaoList);
        }

        isVenuer = Utility.getSharedPreferencesBoolean(mContext, API.IS_VENUE_OWNER);

        Log.d("fnsalkfnasl", "onCreateView: " + isVenuer);

//        if (isVenuer) {
        venueViewModel = ViewModelProviders.of(this).get(VenueViewModel.class);
        venuePicInEventAdapter = new VenuePicInEventAdapter(false);
        binding.venueRv.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
        binding.venueRv.setHasFixedSize(true);
        binding.venueRv.setAdapter(venuePicInEventAdapter);
        binding.locVenueTv.setText("Select a Venue");
        binding.venueLocEt.setHint("Select a Venue");
        binding.imageView23.setVisibility(View.INVISIBLE);
        binding.venueNameLayout.setVisibility(View.GONE);


        if (createEventDAO != null) {
            selectedVenue = new VenueDAO();
            selectedVenue.setId(createEventDAO.getVenueId());
            if (createEventDAO.getVenueImageList() != null)
                venuePicInEventAdapter.refresh(createEventDAO.getVenueImageList());
        }

        fetchVenueImages();
//        }

//        else {
//            binding.venueImageTv.setVisibility(View.GONE);
//            binding.venueRv.setVisibility(View.GONE);
//        }

        getLocationPermission();

        Places.initialize(mContext, getString(R.string.google_maps_key));

        viewModel.getDaysSelected().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {

                binding.typeSubSpinner.setTextColor(ContextCompat.getColor(getActivity(), R.color.grayLight));


                if (eventOccuranceType.equals("weekly"))
                    binding.parentLayout.setVisibility(View.GONE);

                createEventDAO.setOccorredOnDays(s);
                if (s.length() > 0) {
                    binding.typeSubSpinner.setText(s);
                    binding.typeSubSpinner.setTextColor(ContextCompat.getColor(getActivity(), R.color.gray));
                } else if (binding.typeSpinner.getSelectedItemPosition() == 1)
                    binding.typeSubSpinner.setText("Select Days");
                else if (binding.typeSpinner.getSelectedItemPosition() == 2)
                    binding.typeSubSpinner.setText(getString(R.string.select_days));
                else
                    binding.typeSubSpinner.setText(getString(R.string.select_months));
            }
        });

        binding.parentLayout.setOnTouchListener((view, motionEvent) -> {
            binding.parentLayout.setVisibility(View.GONE);
            return true;
        });

        binding.typeSubSpinner.setOnClickListener(v -> {
            if (update) {
                binding.parentLayout.setVisibility(View.GONE);
                return;
            }
            binding.parentLayout.setVisibility(View.VISIBLE);

        });

        binding.venueLocEt.setOnClickListener(v -> {
//            if (isVenuer)
//            else
//                searchForPlace();
            if (update) {
                startActivityForResult(new Intent(getActivity(), MyVenues.class).putExtra("from", "create_venue").putExtra("eventId", updateEventDao.getId()), 101);
            } else {
                startActivityForResult(new Intent(getActivity(), MyVenues.class).putExtra("from", "create_venue"), 101);
            }
        });

        binding.tvSubVenue.setOnClickListener(v -> {
            if (update) {
                startActivityForResult(new Intent(getActivity(), MyVenues.class).putExtra("from", "create_venue").putExtra("eventId", updateEventDao.getId()), 101);
            } else {
                startActivityForResult(new Intent(getActivity(), MyVenues.class).putExtra("from", "create_venue"), 101);
            }
        });

        binding.imageView23.setOnClickListener(v -> searchForPlace());

        binding.addImage.setOnClickListener(v -> {
            checkForPermission();
        });

        binding.endDateImg.setOnClickListener(v -> {
            if (binding.textView39.getText().equals(getString(R.string.start_date)))
                Toast.makeText(mContext, "Select start date first!", Toast.LENGTH_LONG).show();
            else
                Dialogs.setDate(mContext, binding.textView39.getText().toString(), binding.endDateTv, date -> {
                    binding.endDateTv.setText(date);
                    binding.endTimeTv.setText(getString(R.string.end_time));
                });
        });

        binding.endDateTv.setOnClickListener(v -> {
            if (binding.textView39.getText().equals(getString(R.string.start_date)))
                Toast.makeText(mContext, "Select start date first!", Toast.LENGTH_LONG).show();
            else
                Dialogs.setDate(mContext, binding.textView39.getText().toString(), binding.endDateTv, date -> {
                    binding.endDateTv.setText(date);
                    binding.endTimeTv.setText(getString(R.string.end_time));
                });
        });

        binding.imageView22.setOnClickListener(v -> Dialogs.setDate(mContext, "", binding.textView39, date -> {
            binding.textView39.setText(date);
            binding.endDateTv.setText(getString(R.string.end_date));
            binding.endTimeTv.setText(getString(R.string.end_time));
        }));
        binding.textView39.setOnClickListener(v -> Dialogs.setDate(mContext, "", binding.textView39, date -> {
            binding.textView39.setText(date);
            binding.endDateTv.setText(getString(R.string.end_date));
            binding.endTimeTv.setText(getString(R.string.end_time));
        }));

        binding.startTimeImg.setOnClickListener(v -> Dialogs.setTime(mContext, binding.startTimeTv, time -> {
            binding.startTimeTv.setText(time);
            binding.endTimeTv.setText(getString(R.string.end_time));
        }));
        binding.startTimeTv.setOnClickListener(v -> Dialogs.setTime(mContext, binding.startTimeTv, time -> {
            binding.startTimeTv.setText(time);
            binding.endTimeTv.setText(getString(R.string.end_time));
        }));

        binding.endTimeImg.setOnClickListener(this::setEndTime);
        binding.endTimeTv.setOnClickListener(this::setEndTime);

        binding.contactChipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            Chip chip = binding.getRoot().findViewById(checkedId);

            if (chip != null && createEventDAO.getPaidType() != null && !createEventDAO.getPaidType().equals(chip.getText().toString())) {
                if (createEventDAO.getFreeTicketDaoList() != null && createEventDAO.getFreeTicketDaoList().size() > 0)
                    createEventDAO.getFreeTicketDaoList().clear();

                if (createEventDAO.getRsvpTicketDaoList() != null && createEventDAO.getRsvpTicketDaoList().size() > 0)
                    createEventDAO.getRsvpTicketDaoList().clear();

                if (createEventDAO.getVipTicketDaoList() != null && createEventDAO.getVipTicketDaoList().size() > 0)
                    createEventDAO.getVipTicketDaoList().clear();

                if (createEventDAO.getRsvpTableAndSeatingDaos() != null && createEventDAO.getRsvpTableAndSeatingDaos().size() > 0)
                    createEventDAO.getRsvpTableAndSeatingDaos().clear();

                if (createEventDAO.getVipTableAndSeatingDaos() != null && createEventDAO.getVipTableAndSeatingDaos().size() > 0)
                    createEventDAO.getVipTableAndSeatingDaos().clear();
            }

            eventType = (chip != null) ? chip.getText().toString() : "";

        });

        binding.createTicket.setOnClickListener(V -> {
            if (validateAndSetData(V)) {


                Navigation.findNavController(V).navigate(
                        CreateEventFragmentDirections.actionCreateEventFragmentToCreateTicketFragment().setEventDAO(createEventDAO));

//                createEventDAO.setTicketInfoWhenTicketsNotSelected(null);
//                Navigation.findNavController(V).navigate(
//                        CreateEventFragmentDirections.actionCreateEventFragmentToSeatingAndPricingFragment().setEventDAO(createEventDAO));

            }
        });

        binding.postEvent.setOnClickListener(v -> {
            if (validateAndSetData(v)) {
                confirmPaidFreeDialog(v);
            }
        });

        return binding.getRoot();
    }

    private void setViewData() {
        binding.sellTimeCv.setVisibility(View.VISIBLE);
        binding.textView23.setVisibility(View.GONE);
        binding.contactChipGroup.setVisibility(View.GONE);
        binding.view19.setVisibility(View.GONE);
        binding.updateBtn.setVisibility(View.VISIBLE);
        binding.buttonLayout.setVisibility(View.GONE);

        imageDaoList = new ArrayList<>();
        String eventName = updateEventDao.getName();
        binding.eventNameEt.setText(eventName);
        binding.eventNameEt.setSelection(eventName.length());

        String occuranceType = updateEventDao.getEventOccurrenceType();

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_dropdown_item, new String[]{
                occuranceType
        });
        binding.typeSpinner.setAdapter(dataAdapter);
        binding.typeSpinner.setEnabled(false);
        if (occuranceType.equals("oneTime"))
            binding.typeSubLayout.setVisibility(View.GONE);
        else {
            binding.typeSubLayout.setVisibility(View.VISIBLE);
            StringBuilder builder = new StringBuilder();

            if (occuranceType.equals("weekly")) {
                builder.append(Constants.days[updateEventDao.getEventOccurrence().get(0).getOccurredOn()]);
            } else if (occuranceType.equals("daily")) {
                for (int i = 0; i < updateEventDao.getEventOccurrence().size(); i++) {
                    try {
                        if (i == 0) {
                            builder.append(Constants.days[
                                    updateEventDao.getEventOccurrence().get(i).getOccurredOn()
                                    ]);
                        } else {
                            builder.append(",").append(Constants.days[
                                    updateEventDao.getEventOccurrence().get(i).getOccurredOn()
                                    ]);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                for (int i = 0; i < updateEventDao.getEventOccurrence().size(); i++) {
                    if (i == 0) {
                        builder.append(updateEventDao.getEventOccurrence().get(i).getOccurredOn());
                    } else {
                        builder.append(",").append(updateEventDao.getEventOccurrence().get(i).getOccurredOn());
                    }
                }
            }
            binding.typeSubSpinner.setText(builder.toString());
        }

        Log.e(updateEventDao.getStart(), updateEventDao.getEnd());

        binding.textView39.setText(Utility.getDateMonthYearName(updateEventDao.getStart(), true));
        binding.endDateTv.setText(Utility.getDateMonthYearName(updateEventDao.getEnd(), true));
        binding.startTimeTv.setText(StringUtils.getTime(updateEventDao.getStart()));
        binding.endTimeTv.setText(StringUtils.getTime(updateEventDao.getEnd()));

        selectedVenue = updateEventDao.getVenue();
        selectedVenue.setId(updateEventDao.getVenueId());
//        binding.venueNameEt.setText(selectedVenue.getName());
        binding.venueLocEt.setText(selectedVenue.getName());
        if (updateEventDao.getSubVenueEvent() != null && updateEventDao.getSubVenueEvent().size() > 0) {
            binding.tvSubVenue.setVisibility(View.VISIBLE);
            StringBuilder subVenue = new StringBuilder();
            for (int i = 0; i < updateEventDao.getSubVenueEvent().size(); i++) {
                SubVenue sub = updateEventDao.getSubVenueEvent().get(i).getSubVenues().get(0);
                subVenue.append(sub.getSubVenueName()).append(" ( ").append(sub.getSubVenueCapacity()).append(" ) ").append(",");
            }
            subVenue.deleteCharAt(subVenue.length() - 1).toString();
            binding.tvSubVenue.setText(subVenue.toString());
        } else {
            binding.tvSubVenue.setVisibility(View.GONE);
        }
        binding.additionEt.setText(updateEventDao.getDescription());
        binding.additionEt.setEnabled(false);
        binding.additionEt2.setText(updateEventDao.getDescription2());
        binding.sellSwitch.setChecked(updateEventDao.isIs_availability());

        for (EventImages images : updateEventDao.getEventImages()) {
            ImageDAO imageDAO = new ImageDAO(images.getId(), images.getEventImage(), images.isPrimary());
            previousImages.add(imageDAO);
            galleryPicAdapter.refresh(previousImages);
        }

        if (imageDaoList != null && imageDaoList.size() > 0 || previousImages != null && previousImages.size() > 0) {
            binding.tvShowNote.setVisibility(View.GONE);
        } else {
            binding.tvShowNote.setVisibility(View.VISIBLE);
        }

        if (imageDaoList != null && imageDaoList.size() == 5 || previousImages != null && previousImages.size() == 5)
            binding.addImage.setVisibility(View.GONE);
        else
            binding.addImage.setVisibility(View.VISIBLE);

        binding.imageView22.setOnClickListener(v -> {
            Dialogs.setMinMaxDate(getContext(), "", updateEventDao.getStart(), binding.textView39, date -> {
                binding.textView39.setText(date);
                binding.startTimeTv.setText(getString(R.string.start_time));
                binding.endDateTv.setText(getString(R.string.end_date));
                binding.endTimeTv.setText(getString(R.string.end_time));
                setSellingDate();
            });
        });


        binding.textView39.setOnClickListener(v -> {
            Dialogs.setMinMaxDate(getContext(), getTodayDate, updateEventDao.getStart(), binding.textView39, date -> {
                selectedStartEventDate = date;
                binding.textView39.setText(date);
                binding.startTimeTv.setText(getString(R.string.start_time));
                binding.endDateTv.setText(getString(R.string.end_date));
                binding.endTimeTv.setText(getString(R.string.end_time));


                binding.textView59.setText(getString(R.string.start_date));
                binding.endDateTv2.setText(getString(R.string.end_date));
                binding.startTimeTv2.setText(getString(R.string.start_time));
                binding.endTimeTv2.setText(getString(R.string.end_time));

                //setSellingDate();
            });
        });
        binding.endDateImg.setOnClickListener(v -> {
            if (binding.textView39.getText().equals(getString(R.string.start_date)))
                Toast.makeText(getContext(), "Select start date first!", Toast.LENGTH_LONG).show();
            else
                Dialogs.setMinMaxDate(getContext(), binding.textView39.getText().toString(), updateEventDao.getStart(), binding.textView39, date -> {
                    setSellingDate();
                    binding.endDateTv.setText(date);
                });
        });
        binding.endDateTv.setOnClickListener(v -> {
            if (binding.textView39.getText().equals(getString(R.string.start_date)))
                Toast.makeText(getContext(), "Select start date first!", Toast.LENGTH_LONG).show();
            else
                Dialogs.setMinMaxDate(getContext(), binding.textView39.getText().toString(), updateEventDao.getStart(), binding.textView39, date -> {
                    binding.endDateTv.setText(date);
                    //setSellingDate();

                });
        });
        setSellingDate();
        binding.updateBtn.setOnClickListener(v -> {
            startDate = binding.textView39.getText().toString();
            endDate = binding.endDateTv.getText().toString();
            startTime = binding.startTimeTv.getText().toString();
            endTime = binding.endTimeTv.getText().toString();
//            venueName = binding.venueNameEt.getText().toString();
            venueName = binding.venueLocEt.getText().toString().trim();

            startSellingDate = binding.textView59.getText().toString();
            endSellingDate = binding.endDateTv2.getText().toString();
            startSellingTime = binding.startTimeTv2.getText().toString();
            endSellingTime = binding.endTimeTv2.getText().toString();
            sortDescription = binding.additionEt2.getText().toString();


            JsonArray occuranceOnList = new JsonArray();

            Date startDateUtil = null, endDateUtil = null;
            Date startSellingDateUtil = null, endSellingDateUtil = null;

            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.ENGLISH);
            SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.ENGLISH);
//            if(binding.typeSubLayout.isShown()){
//                for(int i =0 ;i<dao.getEventOccurrence().size();i++){
//                    occuranceOnList.add(dao.getEventOccurrence().get(i).getOccurredOn());
//                }
//            }
            try {
                startDateUtil = sdf.parse(startDate + " " + startTime);
                endDateUtil = sdf.parse(endDate + " " + endTime);

                startSellingDateUtil = sdf1.parse(startSellingDate + " " + startSellingTime);
                endSellingDateUtil = sdf1.parse(endSellingDate + " " + endSellingTime);


            } catch (ParseException e) {
                e.printStackTrace();
                Log.d("fnalsnfklsa", e.getMessage() + " ParseException: ");
            }

            String additionalInfo2 = binding.additionEt2.getText().toString().trim();
            if (TextUtils.isEmpty(binding.eventNameEt.getText().toString())) {
                Dialogs.toast(mContext, v, getString(R.string.event_name));
                binding.eventNameEt.requestFocus();
                return;
            } else if (venueName == null || TextUtils.isEmpty(venueName)) {
                Dialogs.toast(mContext, v, getString(R.string.venueNameRequired));
                binding.venueLocEt.requestFocus();
                return;
            } else if (startDate.equals(getString(R.string.start_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartDateRequired));
                return;
            } else if (endDate.equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
                return;
            } else if (startTime.equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
                return;
            } else if (endTime.equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
                return;
            } else if (imageDaoList.size() == 0 && previousImages.size() == 0) {
                Dialogs.toast(mContext, v, getString(R.string.galleryImageRequired));
                return;
            } else if (!additionalInfo2.isEmpty() && additionalInfo2.length() < 200) {
                binding.additionEt2.requestFocus();
                Dialogs.toast(mContext, v, getString(R.string.addOnMin));
                return;
            }
            else if (!additionalInfo2.isEmpty() && additionalInfo2.length() > 2500) {
                binding.additionEt2.requestFocus();
                Dialogs.toast(mContext, v, getString(R.string.addOnMax));
                return;
            }
            else if (startSellingDate.equals(getString(R.string.start_date))) {
                Dialogs.toast(mContext, v, getString(R.string.select_selling_date));
                return;
            } else if (endSellingDate.equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.selling_end_date));
                return;
            } else if (startSellingTime.equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.selling_start_time));
                return;
            } else if (endSellingTime.equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.selling_end_time));
                return;
            }
            loader.show("Please Wait...");


            Log.d("nfklasnklfnaksl", "setViewData: ");

            Map<String, RequestBody> requestBodyMap = new HashMap<>();

            requestBodyMap.put("name", RequestBody.create(MediaType.parse("multipart/form-data"), binding.eventNameEt.getText().toString()));

            Log.d("fnaslfnlak", "setViewData: " + selectedVenue.getId());


            if (update) {
                if (previousImages != null && previousImages.size() > 0) {
                    if (previousImages.get(0).getId() > 0) {
                        int id = previousImages.get(0).getId();
                        requestBodyMap.put("imageId", RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(id)));
                    }
                }
            }

//            if (isVenuer)
            requestBodyMap.put("venueId", RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(selectedVenue.getId())));
            RequestBody subVenue = null;
            int userId = Utility.getSharedPreferencesInteger(getActivity(), API.USER_ID);
            JsonArray jsonArray = new JsonArray();
            if (updateSelectedSubVenues != null && updateSelectedSubVenues.size() > 0) {
                for (int i = 0; i < updateSelectedSubVenues.size(); i++) {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("userId", userId);
                    jsonObject.addProperty("venueId", updateSelectedSubVenues.get(i).getVenueId());
                    jsonObject.addProperty("subVenueId", updateSelectedSubVenues.get(i).getSubVenueId());
                    if (update) {
                        jsonObject.addProperty("eventId", updateEventDao.getId());
                        if (updateSelectedSubVenues.get(i).getSubVenueEventId() != 0) {
                            jsonObject.addProperty("id", updateSelectedSubVenues.get(i).getSubVenueEventId());
                        }
                        jsonObject.addProperty("status", "booked");
                    } else {
                        jsonObject.addProperty("status", updateSelectedSubVenues.get(i).getStatus());
                    }
                    jsonArray.add(jsonObject);
                }
            }
            subVenue = RequestBody.create(MediaType.parse("multipart/form-data"), jsonArray.toString());
//            else {
//                requestBodyMap.put("venueName", RequestBody.create(MediaType.parse("multipart/form-data"), venueName));
//
//                requestBodyMap.put("venueAddress", RequestBody.create(MediaType.parse("multipart/form-data"), venueAddress));
//
//                requestBodyMap.put("venueLatitude", RequestBody.create(MediaType.parse("multipart/form-data"),
//                        latLongt == null ? selectedVenue.getLatitude() : String.valueOf(latLongt.latitude)));
//                requestBodyMap.put("venueLongitude", RequestBody.create(MediaType.parse("multipart/form-data"), latLongt == null ? selectedVenue.getLongitude() : String.valueOf(latLongt.longitude)));
//                requestBodyMap.put("countryCode", RequestBody.create(MediaType.parse("multipart/form-data"), binding.cpp.getDefaultCountryCodeWithPlus()));
//                requestBodyMap.put("city", RequestBody.create(MediaType.parse("multipart/form-data"), latLongt == null ? Utility.getCity(activity, Double.parseDouble(selectedVenue.getLatitude()), Double.parseDouble(selectedVenue.getLongitude())) : Utility.getCity(activity, latLongt.latitude, latLongt.longitude)));
//                requestBodyMap.put("state", RequestBody.create(MediaType.parse("multipart/form-data"), latLongt == null ? Utility.getState(activity, Double.parseDouble(selectedVenue.getLatitude()), Double.parseDouble(selectedVenue.getLongitude())) : Utility.getState(activity, latLongt.latitude, latLongt.longitude)));
//            }
            requestBodyMap.put("start", RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(startDateUtil)));
            requestBodyMap.put("end", RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(endDateUtil)));
//
//
//            Log.d("famsfanlnl", " SELLINGDAE: " + (Utility.localToUTC(startSellingDateUtil)) + " --- " + Utility.localToUTC(endSellingDateUtil));
//

            requestBodyMap.put("sellingStart", RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(startSellingDateUtil)));
            requestBodyMap.put("sellingEnd", RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(endSellingDateUtil)));


            requestBodyMap.put("imageIds", RequestBody.create(MediaType.parse("multipart/form-data"), deletedPreviousImagesIds.toString()));
            requestBodyMap.put("id", RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(updateEventDao.getId())));


            requestBodyMap.put("description2", RequestBody.create(MediaType.parse("multipart/form-data"), sortDescription));
            requestBodyMap.put("subVenueEvent", subVenue);

            Log.d("fsnaklfnsa", occuranceOnList.toString() + " set====ViewData: " + deletedPreviousImagesIds);

            viewModel.editEventRequest(requestBodyMap, imageDaoList).observe(getViewLifecycleOwner(), myResponse -> {
                loader.dismiss();
                if (myResponse.isSuccess()) {
                    //success event edit http request
                    Utility.setSharedPreferencesBoolean(activity, API.HOT_RELOAD_EVENTS, true);
                    Utility.setSharedPreferencesBoolean(activity, API.HOT_RELOAD_PAST_EVENTS, true);
                    Utility.setSharedPreferencesBoolean(activity, API.HOT_RELOAD, true);
                    Toast.makeText(mContext, myResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    activity.setResult(RESULT_OK);
                    activity.onBackPressed();

                } else {
                    //failed event edit http request
                    Toast.makeText(mContext, "Something went wrong", Toast.LENGTH_SHORT).show();

                }
            });
        });


    }

    private boolean validateAndSetData(View V) {

        selection = new StringBuilder();

        startDate = binding.textView39.getText().toString();
        endDate = binding.endDateTv.getText().toString();
        startTime = binding.startTimeTv.getText().toString();
        endTime = binding.endTimeTv.getText().toString();

        String name = binding.eventNameEt.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            binding.eventNameEt.requestFocus();
            Dialogs.toast(mContext, V, getString(R.string.enter_name_of_event));
            return false;
        }

        String selectedAvailability = binding.typeSubSpinner.getText().toString();
        if ((selectedAvailability.equals("Select Days") ||
                selectedAvailability.equals("Select Months")) &&
                !eventOccuranceType.equals("oneTime")) {
            Dialogs.toast(mContext, V, eventOccuranceType.equals("monthly") ? "Select months please!" : "Select Days please!");
            return false;
        }

        if (eventOccuranceType.equals("daily")) {
            String sarr[] = selectedAvailability.split(", ");
            for (int i = 0; i < sarr.length; i++) {
                if (i == 0) {
                    selection.append("[").append(StringUtils.getDayMonthNum(sarr[i]) + "");
                } else
                    selection.append(",").append(StringUtils.getDayMonthNum(sarr[i]) + "");

                if ((i + 1) == sarr.length)
                    selection.append("]");
            }
        }
        if (eventOccuranceType.equals("monthly")) {
            String sarr[] = selectedAvailability.split(", ");
            for (int i = 0; i < sarr.length; i++) {
                if (i == 0) {
                    selection.append("[").append(sarr[i]);
                } else
                    selection.append(",").append(sarr[i]);

                if ((i + 1) == sarr.length)
                    selection.append("]");
            }
        }

        if (eventOccuranceType.equals("weekly")) {

            if (selectedAvailability.equals("Select Day")) {
                Dialogs.toast(mContext, V, "Select Day please!");
                return false;
            }

            switch (selectedAvailability) {
                case "Sunday":
                    selection.append("[0]");
                    break;
                case "Monday":
                    selection.append("[1]");
                    break;
                case "Tuesday":
                    selection.append("[2]");
                    break;
                case "Wednesday":
                    selection.append("[3]");
                    break;
                case "Thursday":
                    selection.append("[4]");
                    break;
                case "Friday":
                    selection.append("[5]");
                    break;
                case "Saturday":
                    selection.append("[6]");
                    break;
            }
        }

        if (startDate.equals(getString(R.string.start_date))) {
            Dialogs.toast(mContext, V, getString(R.string.eventStartDateRequired));
            return false;
        }


        if (endDate.equals(getString(R.string.end_date))) {
            Dialogs.toast(mContext, V, getString(R.string.eventEndDateRequired));
            return false;
        }


        if (startTime.equals(getString(R.string.start_time))) {
            Dialogs.toast(mContext, V, getString(R.string.eventStartTimeRequired));
            return false;
        }


        if (endTime.equals(getString(R.string.end_time))) {
            Dialogs.toast(mContext, V, getString(R.string.eventEndTimeRequired));
            return false;
        }

        if (selectedVenue == null) {
            Dialogs.toast(mContext, V, getString(R.string.venueNoAvailabilty));
            return false;
        }
//
//        venueName = binding.venueNameEt.getText().toString().trim();
//        if (!isVenuer && venueName.length() == 0) {
//            Dialogs.toast(mContext, V, getString(R.string.venueNameRequired));
//            binding.venueNameEt.requestFocus();
//            return false;
//        }


//        if (!isVenuer && latLongt == null) {
//            Dialogs.toast(mContext, V, getString(R.string.venueLocationRequired));
//            return false;
//        }


        if (imageDaoList.size() == 0) {
            Dialogs.toast(mContext, V, getString(R.string.galleryImageRequired));
            return false;
        }


        String additionalInfo = binding.additionEt.getText().toString().trim();
        if (additionalInfo.length() < 200) {
            binding.additionEt.requestFocus();
            Dialogs.toast(mContext, V, getString(R.string.eventDetailMin));
            return false;
        }
        if (additionalInfo.length() > 2500) {
            binding.additionEt.requestFocus();
            Dialogs.toast(mContext, V, getString(R.string.eventDetailMax));
            return false;
        }


        String additionalInfo2 = binding.additionEt2.getText().toString().trim();
        if (!additionalInfo2.isEmpty() && additionalInfo2.length() < 200) {
            binding.additionEt2.requestFocus();
            Dialogs.toast(mContext, V, getString(R.string.addOnMin));
            return false;
        }
        if (!additionalInfo2.isEmpty() && additionalInfo2.length() > 2500) {
            binding.additionEt2.requestFocus();
            Dialogs.toast(mContext, V, getString(R.string.addOnMax));
            return false;
        }

        if (eventType.length() == 0) {
            Dialogs.toast(mContext, V, "Choose event type!");
            return false;
        }

        createEventDAO.setName(name);
        createEventDAO.setEventOccuranceType(eventOccuranceType);
        createEventDAO.setOccurredOn(selection.toString());

        createEventDAO.setStartDate(startDate);
        createEventDAO.setEndDate(endDate);
        createEventDAO.setStartTime(startTime);
        createEventDAO.setEndTime(endTime);

//        if (!isVenuer) {
        createEventDAO.setVenueName(venueName);
//            createEventDAO.setLat(String.valueOf(latLongt.latitude));
//            createEventDAO.setLongt(String.valueOf(latLongt.longitude));
//        }

        createEventDAO.setDesc(additionalInfo);
        createEventDAO.setDesc2(additionalInfo2);
//        createEventDAO.setVenueAddress(binding.venueLocEt.getText().toString().trim());
        createEventDAO.setPaidType(eventType);
        createEventDAO.setImageList(imageList);
        createEventDAO.setImageDAOList(imageDaoList);


        return true;
    }

    /*private void setStartTime(View v) {
        Dialogs.setTime(getContext(), binding.endTimeTv, time -> {
            if (!binding.textView39.getText().equals(!update ? createEventDAO.getStartDate() : updateEventDao.getStart()))
                binding.startTimeTv.setText(time);
            else if (compareTime(time, !update ? createEventDAO.getStartTime() : updateEventDao.getStart()))
                binding.startTimeTv.setText(time);

            else {
                Dialogs.toast(getContext(), v, "Sell start time must be earlier than Event start time");
                binding.startTimeTv.setText(getString(R.string.start_time));
            }
        });
    }*/

    private boolean compareTime(String startTime, String endTime) {

        int startHour = getHour(startTime);
        int endHour = getHour(endTime);

        if (endHour > startHour) return true;

        else if (endHour == startHour) {
            int startMin = Integer.valueOf(startTime.substring(3, 5));
            int endMin = Integer.valueOf(endTime.substring(3, 5));
            return endMin > startMin;
        }
        return false;
    }

    private int getHour(String time) {
        int startHour = Integer.valueOf(time.substring(0, 2));
        return time.matches("(.*)PM") && startHour < 12 ? (startHour + 12) : startHour;
    }

    private void setEndTime(View v) {
        if (binding.startTimeTv.getText().toString().equals(getString(R.string.start_time)))
            Toast.makeText(mContext, "Select start time first!", Toast.LENGTH_LONG).show();
        else
            Dialogs.setTime(mContext, binding.endTimeTv, time -> {
                if (!binding.textView39.getText().equals(binding.endDateTv.getText().toString())) {
                    binding.endTimeTv.setText(time);
                } else {
                    String startTime = binding.startTimeTv.getText().toString();

                    int startHour = Integer.valueOf(startTime.substring(0, 2));
                    int endHour = Integer.valueOf(time.substring(0, 2));

                    if ((startTime.matches("(.*)PM") || startTime.matches("(.*)pm")) && startHour < 12)
                        startHour += 12;

                    if ((time.matches("(.*)PM") || time.matches("(.*)pm")) && endHour < 12)
                        endHour += 12;

                    if (endHour > startHour)
                        binding.endTimeTv.setText(time);

                    else if (endHour == startHour) {
                        int startMin = Integer.valueOf(startTime.substring(3, 5));
                        int endMin = Integer.valueOf(time.substring(3, 5));
                        if (endMin > startMin)
                            binding.endTimeTv.setText(time);
                        else {
                            Dialogs.toast(mContext, v, "Start time must be greater than End time");
                            binding.endTimeTv.setText(getString(R.string.end_time));
                        }
                    } else {
                        Dialogs.toast(mContext, v, "Start time must be greater than End time");
                        binding.endTimeTv.setText(getString(R.string.end_time));
                    }


                }
            });
    }

    private void checkForPermission() {
        final String[] permissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        permissionUtils = new PermissionUtils(this)
                .setCode(RC_HANDLE_CAMERA_PERM)
                .setPermissions(permissions)
                .onAlreadyGranted(this::choose)
                .build();
    }

    private void searchForPlace() {
        if (mLocationPermissionGranted) {

            List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS, Place.Field.LAT_LNG);
            Intent intent = new Autocomplete.IntentBuilder(
                    AutocompleteActivityMode.OVERLAY, fields)
                    .build(mContext);
            startActivityForResult(intent, PLACE_PICKER_REQUEST_CODE);

        } else
            getLocationPermission();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 222:
                if (resultCode == RESULT_OK) {
                    binding.additionEt.requestFocus();
                    if (data != null && data.getData() != null) {
                        try {
                            setPicBrowsedByGallery(data);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else
                        pickImageFromCamera();
                }
                break;

            case PLACE_PICKER_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    Place place = Autocomplete.getPlaceFromIntent(data);
                    binding.venueLocEt.setText(place.getAddress());
                    latLongt = place.getLatLng();
                    String code = Utility.countryCode(mContext, latLongt.latitude, latLongt.longitude);
                    binding.cpp.setCountryForNameCode(code);

                    if (!update) {
                        createEventDAO.setCountryCode(code);
                        createEventDAO.setCityName(Utility.getCity(mContext, latLongt.latitude, latLongt.longitude));
                    }

                } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                    // TODO: Handle the error.
                    Status status = Autocomplete.getStatusFromIntent(data);
                    Log.e("WIG", status.getStatusMessage());
                } else if (resultCode == RESULT_CANCELED) {

                }

                break;


            case 101:
                if (resultCode == RESULT_OK) {
                    binding.additionEt.requestFocus();
                    selectedVenue = (VenueDAO) data.getParcelableExtra("venue");
                    if (selectedVenue != null) {
                        binding.venueLocEt.setText(selectedVenue.getName());
                        if (selectedVenue.getSelectedSubVenues() != null && selectedVenue.getSelectedSubVenues().size() > 0) {
                            binding.tvSubVenue.setVisibility(View.VISIBLE);
                            StringBuilder subVenue = new StringBuilder();
                            for (int i = 0; i < selectedVenue.getSelectedSubVenues().size(); i++) {
                                subVenue.append(selectedVenue.getSelectedSubVenues().get(i).getSubVenueName()).append(" ( ").append(selectedVenue.getSelectedSubVenues().get(i).getSubVenueCapacity()).append(" ) ").append(" ,");
                            }
                            subVenue.deleteCharAt(subVenue.length() - 1).toString();
                            binding.tvSubVenue.setText(subVenue.toString());
                            if (update) {
                                updateSelectedSubVenues.addAll(selectedVenue.getSelectedSubVenues());
                            } else if (createEventDAO != null) {
                                createEventDAO.setVenueName(selectedVenue.getName());
                                createEventDAO.setVenueId(selectedVenue.getId());
                                createEventDAO.setSelectedSubVenues(selectedVenue.getSelectedSubVenues());
                            }
                        } else {
                            binding.tvSubVenue.setVisibility(View.GONE);
                            if (createEventDAO != null) {
                                createEventDAO.setVenueName(selectedVenue.getName());
                                createEventDAO.setVenueId(selectedVenue.getId());
                            }
                        }

                        fetchVenueImages();
                    }
                }
                break;
        }
    }

    String getRealPathFromURI(Uri uri) {
        Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
        if (cursor == null) return uri.getPath();
        else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(idx);
        }
    }

    private void setGalleryAdapter() {
        galleryPicAdapter = new GalleryPicAdapter(true, (s, position) -> {
            if (previousImages != null && previousImages.size() > 0) {
                ImageDAO dao = new ImageDAO(s);
                imageDaoList.remove(dao);
                int index = previousImages.indexOf(dao);
                int selectedImgListIndex = imageDaoList.indexOf(dao);
                galleryPicAdapter.notifyItemRemoved(selectedImgListIndex);
                if (index != -1) {
                    ImageDAO uploadedDao = previousImages.remove(index);
                    if (TextUtils.isEmpty(deletedPreviousImagesIds)) {
                        deletedPreviousImagesIds.append(uploadedDao.getId());
                    } else
                        deletedPreviousImagesIds.append(",").append(uploadedDao.getId());
                }
            } else {
                imageDaoList.remove(position);
                galleryPicAdapter.notifyItemRemoved(position);
            }
            if (imageDaoList != null && imageDaoList.size() == 5 || previousImages != null && previousImages.size() == 5) {
                binding.addImage.setVisibility(View.GONE);
            } else {
                binding.addImage.setVisibility(View.VISIBLE);
            }

            galleryPicAdapter.notifyDataSetChanged();
        });
        binding.galleryRv.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.galleryRv.setHasFixedSize(true);
        binding.galleryRv.setAdapter(galleryPicAdapter);
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(binding.galleryRv);
    }

    private void setPicBrowsedByGallery(Intent data) {
        if (data != null && data.getData() != null) {
            String filePath = FileUtils.getPath(activity, data.getData());

            if (filePath != null && filePath.length() > 0) {
                ImageDAO dao = new ImageDAO(filePath);
                if (!imageDaoList.contains(dao)) {
                    if (update) {
                        previousImages.add(dao);
                        imageDaoList.add(dao);
                        galleryPicAdapter.refresh(previousImages);
                    } else {
                        imageDaoList.add(dao);
                        galleryPicAdapter.refresh(imageDaoList);
                    }
                } else {
                    Toast.makeText(mContext, "Picture is already in list", Toast.LENGTH_LONG).show();
                }
                if (imageDaoList != null && imageDaoList.size() > 0 || previousImages != null && previousImages.size() > 0) {
                    binding.tvShowNote.setVisibility(View.GONE);
                } else {
                    binding.tvShowNote.setVisibility(View.VISIBLE);
                }
                if (imageDaoList.size() == 5)
                    binding.addImage.setVisibility(View.GONE);
                else
                    binding.addImage.setVisibility(View.VISIBLE);

            }
        } else {
            Toast.makeText(activity, "Please select different image", Toast.LENGTH_SHORT).show();
        }

    }

    private void pickImageFromCamera() {
        ImageDAO dao = new ImageDAO(currentPhotoPath);
        if (!imageDaoList.contains(dao)) {
            if (update) {
                previousImages.add(new ImageDAO(currentPhotoPath));
                imageDaoList.add(new ImageDAO(currentPhotoPath));
                galleryPicAdapter.refresh(previousImages);
            } else {
                imageDaoList.add(new ImageDAO(currentPhotoPath));
                galleryPicAdapter.refresh(imageDaoList);
            }
            if (imageDaoList.size() == 5)
                binding.addImage.setVisibility(View.GONE);
            else
                binding.addImage.setVisibility(View.VISIBLE);
            galleryAddPic();
            setPic();
        } else {
            Toast.makeText(mContext, "Picture is already in list", Toast.LENGTH_LONG).show();
        }
        if (imageDaoList != null && imageDaoList.size() > 0 || previousImages != null && previousImages.size() > 0) {
            binding.tvShowNote.setVisibility(View.GONE);
        } else {
            binding.tvShowNote.setVisibility(View.VISIBLE);
        }
    }

    private void fetchVenueImages() {
        //System.out.println("selected venue"+selectedVenue.toString());
        if (selectedVenue == null) return;
        Log.d("fnabslfbaklsj", "fetchVenueImages: " + selectedVenue.getId());
        venueViewModel.getVenueImages(selectedVenue.getId()).observe(getViewLifecycleOwner(), response -> {
            if (response.getCode() == API.SESSION_EXPIRE) {
                response.setCode(0);
                Utility.sessionExpired(mContext);
            } else if (response.isSuccess() && response.getVenueImages().size() > 0) {
                binding.venueLayout.setVisibility(View.VISIBLE);
                if (createEventDAO != null)
                    createEventDAO.setVenueImageList(response.getVenueImages());
                venuePicInEventAdapter.refresh(response.getVenueImages());
                venuePicInEventAdapter.notifyDataSetChanged();
                Log.d("hnfklasnfklas", venuePicInEventAdapter.getItemCount() + " fetchVenueImages: " + response.getVenueImages().size());
            }
        });
    }

    private void galleryAddPic() {
        try {
            Log.e("fire.....", "yes");
            Intent mediaScanIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            File f = new File(currentPhotoPath);
            Uri photoURI = FileProvider.getUriForFile(mContext, mContext.getApplicationContext().getPackageName() + ".provider", f);
            mediaScanIntent.setData(photoURI);
            mContext.sendBroadcast(mediaScanIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private ImageView createViewDynamically(String path) {
        LayoutInflater vi = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = vi.inflate(R.layout.my_dynamic_image_editable, null);
        ImageView img = v.findViewById(R.id.myImg);
        img.setImageDrawable(getResources().getDrawable(R.drawable.e_dummy));
        ImageView deleteBtn = v.findViewById(R.id.del_img);
        deleteBtn.setImageDrawable(getResources().getDrawable(R.drawable.ic_clear_white));
        deleteBtn.setTag(path);

        deleteBtn.setOnClickListener(vv -> {
            ImageDAO dao = new ImageDAO(vv.getTag().toString());
            imageDaoList.remove(dao);
            int index = previousImages.indexOf(dao);
            int selectedImgListIndex = imageDaoList.indexOf(dao);
            if (index != -1) {
                ImageDAO uploadedDao = previousImages.remove(index);
                if (TextUtils.isEmpty(deletedPreviousImagesIds)) {
                    deletedPreviousImagesIds.append(uploadedDao.getId());
                } else
                    deletedPreviousImagesIds.append(",").append(uploadedDao.getId());
            } else if (imageDaoList.size() > 0) {
                imageDaoList.remove(selectedImgListIndex);
            }
            if (binding.imageLayout.getChildCount() == 6)
                binding.imageLayout.getChildAt(0).setVisibility(View.VISIBLE);
            binding.imageLayout.removeView(v);

        });

        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams((int) getResources().getDimension(R.dimen._72sdp), (int) getResources().getDimension(R.dimen._72sdp));
        binding.imageLayout.addView(v, lp);


        if (binding.imageLayout.getChildCount() == 6)
            binding.imageLayout.getChildAt(0).setVisibility(View.GONE);

        return img;
    }

    private void setPic() {
        int targetW = binding.myImg.getWidth();
        int targetH = binding.myImg.getHeight();

        Log.e("target W " + targetW, "target H" + targetH);

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;

        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        Log.e("photo W " + photoW, "photo H" + photoH);

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(currentPhotoPath, bmOptions);

        try {
            ExifInterface ei = new ExifInterface(currentPhotoPath);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_UNDEFINED);

            switch (orientation) {

                case ExifInterface.ORIENTATION_ROTATE_90:
                    Bitmap rotatedBitmap = rotateImage(bitmap, 90);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_180:
                    rotatedBitmap = rotateImage(bitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    rotatedBitmap = rotateImage(bitmap, 270);
                    break;

                case ExifInterface.ORIENTATION_NORMAL:
                default:
                    rotatedBitmap = bitmap;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

//        requestManager.load(currentPhotoPath).into(createViewDynamically(currentPhotoPath));
//        galleryPicAdapter.refresh(imageDaoList);
        //currentImageView.setImageBitmap(rotatedBitmap);
    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    private void getLocationPermission() {

        mLocationPermissionGranted = false;
        if (ContextCompat.checkSelfPermission(mContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case RC_HANDLE_CAMERA_PERM: {
                permissionUtils.handle(requestCode, grantResults);
                break;
            }

            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
        }
    }

    private void choose() {
        Intent pickIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pickIntent.addCategory(Intent.CATEGORY_OPENABLE);
        pickIntent.setType("image/*");
        //pickIntent.setAction(Intent.ACTION_GET_CONTENT);

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(mContext.getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(mContext,
                        "com.ebabu.event365live.host.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
            }
        }

        String pickTitle = "Select or take a new Picture"; // Or get from strings.xml
        Intent chooserIntent = Intent.createChooser(pickIntent, pickTitle);
        chooserIntent.putExtra
                (
                        Intent.EXTRA_INITIAL_INTENTS,
                        new Intent[]{takePictureIntent}
                );
        startActivityForResult(chooserIntent, 222);
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = mContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e("called", "onstart");
    }

    @Override
    public void onDestroyView() {
        if (disposable != null) disposable.dispose();
        super.onDestroyView();
    }

    private void setSellingDate() {

        startEventDateFromApi = Utility.getDateMonthYearName(updateEventDao.getStart(), true);
        binding.textView59.setText(Utility.getDateMonthYearName(updateEventDao.getSellingStart(), true));
        binding.endDateTv2.setText(Utility.getDateMonthYearName(updateEventDao.getSellingEnd(), true));
        binding.startTimeTv2.setText(StringUtils.getTime(updateEventDao.getSellingStart()));
        binding.endTimeTv2.setText(StringUtils.getTime(updateEventDao.getSellingEnd()));

        binding.imageView52.setOnClickListener(v -> Dialogs.setMinMaxDate(getContext(), getTodayDate, binding.endDateTv.getText().toString(), binding.textView59, date -> {

            if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
                return;
            } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
                return;
            } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
                return;
            }
            binding.textView59.setText(date);
            binding.startTimeTv2.setText(getString(R.string.start_time));
            binding.endDateTv2.setText(getString(R.string.end_date));
            binding.endTimeTv2.setText(getString(R.string.end_time));
        }));

        binding.textView59.setOnClickListener(v -> {

            if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
                return;
            } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
                return;
            } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
                return;
            }

            Dialogs.setMinMaxDate(getContext(), getTodayDate, binding.endDateTv.getText().toString(), binding.textView59, new Dialogs.OnStartDateSelected() {
                @Override
                public void onSet(String date) {

                    binding.textView59.setText(date);
                    binding.startTimeTv2.setText(getString(R.string.start_time));
                    binding.endDateTv2.setText(getString(R.string.end_date));
                    binding.endTimeTv2.setText(getString(R.string.end_time));
                }
            });


        });

        binding.endDateImg2.setOnClickListener(v -> {


            if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
                return;
            } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
                return;
            } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
                return;
            }


            if (binding.textView59.getText().equals(getString(R.string.start_date)))
                Dialogs.toast(mContext, v, "Select start date first!");
            else
                Dialogs.setMinMaxDate(getContext(), binding.textView59.getText().toString(), binding.endDateTv.getText().toString(), binding.textView59, date -> {

                    if (compareDate(binding.textView39.getText().toString(), date)) {
                        Dialogs.toast(getContext(), v, "Selling end date should not be grater than of end event date");
                        binding.endDateTv2.setText(getString(R.string.end_date));
                        return;
                    }

                    binding.endDateTv2.setText(date);
                });
        });
        binding.endDateTv2.setOnClickListener(v -> {

            if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
                return;
            } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
                return;
            } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
                Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
                return;
            }

            if (binding.textView59.getText().equals(getString(R.string.start_date)))
                Dialogs.toast(getContext(), v, "Select start date first!");
            else
                Dialogs.setMinMaxDate(getContext(), binding.textView59.getText().toString(), binding.endDateTv.getText().toString(), binding.textView59, date -> {
                    if (compareDate(binding.endDateTv.getText().toString(), date)) {
                        Dialogs.toast(getContext(), v, "Selling end date should not be grater than of end event date");
                        //binding.textView59.setText(getString(R.string.start_date));
                        //binding.startTimeTv2.setText(getString(R.string.start_time));
                        binding.endDateTv2.setText(getString(R.string.end_date));
                        //binding.endTimeTv2.setText(getString(R.string.end_time));
                        return;
                    }
                    binding.endDateTv2.setText(date);

                });
        });

        binding.startTimeImg2.setOnClickListener(this::setSellingStartTime);
        binding.startTimeTv2.setOnClickListener(this::setSellingStartTime);
        binding.endTimeImg2.setOnClickListener(this::setSellingEndTime);
        binding.endTimeTv2.setOnClickListener(this::setSellingEndTime);
    }

    private boolean compareDate(String dateOne, String dateTwo) {
        boolean flag = true;// selling date should be not grater than of start event date
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
        try {
            Date d1 = sdf.parse(dateOne);
            Date d2 = sdf.parse(dateTwo);
            if (d1 != null && d2 != null) {
                if (!d1.before(d2)) {
                    flag = false;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return flag;
    }

    private void setSellingStartTime(View v) {

        if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
            Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
            return;
        } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
            Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
            return;
        } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
            Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
            return;
        }


        Dialogs.setTime(getContext(), binding.endTimeTv2, time -> {
            if (!binding.textView59.getText().equals(binding.startTimeTv2.getText().toString()))
                binding.startTimeTv2.setText(time);
            else if (compareSellingTime(time, binding.startTimeTv.getText().toString()))
                binding.startTimeTv2.setText(time);
            else {
                Dialogs.toast(getContext(), v, "Sell start time must be earlier than Event end time");
                binding.startTimeTv2.setText(getString(R.string.start_time));
            }
        });
    }

    private boolean compareSellingTime(String startTime, String endTime) {
        int startHour = getSellingHour(startTime);
        int endHour = getSellingHour(endTime);

        if (endHour > startHour) return true;

        else if (endHour == startHour) {
            int startMin = Integer.parseInt(startTime.substring(3, 5));
            int endMin = Integer.parseInt(endTime.substring(3, 5));
            return endMin > startMin;
        }
        return false;
    }

    private int getSellingHour(String time) {
        int startHour = Integer.parseInt(time.substring(0, 2));
        return time.matches("(.*)PM") && startHour < 12 ? (startHour + 12) : startHour;
    }

    private void setSellingEndTime(View v) {

        if (binding.endDateTv.getText().equals(getString(R.string.end_date))) {
            binding.endTimeTv2.setText(getString(R.string.end_time));
            Dialogs.toast(mContext, v, getString(R.string.eventEndDateRequired));
            return;
        } else if (binding.startTimeTv.getText().equals(getString(R.string.start_time))) {
            binding.endTimeTv2.setText(getString(R.string.end_time));
            Dialogs.toast(mContext, v, getString(R.string.eventStartTimeRequired));
            return;
        } else if (binding.endTimeTv.getText().equals(getString(R.string.end_time))) {
            binding.endTimeTv2.setText(getString(R.string.end_time));
            Dialogs.toast(mContext, v, getString(R.string.eventEndTimeRequired));
            return;
        }

        if (binding.startTimeTv.getText().toString().equals(getString(R.string.start_time)))
            Toast.makeText(getContext(), "Select start time first!", Toast.LENGTH_LONG).show();
        else
            Dialogs.setTime(getContext(), binding.endTimeTv2, time -> {

                if (compareSellingTime(time, binding.endTimeTv.getText().toString())) {
                    binding.endTimeTv2.setText(time);
                } else {
                    Dialogs.toast(getContext(), v, "Sell end time must be earlier than Event end time");
                    binding.endTimeTv2.setText(getString(R.string.end_time));
                }

//                if (binding.endDateTv2.getText().equals(updateEventDao.getEnd())) {
//
//                    if (compareSellingTime(time, binding.endTimeTv.getText().toString()))
//                        binding.endTimeTv2.setText(time);
//                    else {
//                        Dialogs.toast(getContext(), v, "Sell end time must be earlier than Event end time");
//                        binding.endTimeTv2.setText(getString(R.string.end_time));
//                    }
//                } else
//                    binding.endTimeTv2.setText(time);

//                if (!binding.textView59.getText().equals(binding.endDateTv2.getText().toString())) {
//
//
//                }

//                else {
//                    String startTime = binding.startTimeTv2.getText().toString();
//
//                    if (compareSellingTime(startTime, time))
//                        if (binding.endDateTv2.getText().equals(updateEventDao.getStart())) {
//                            if (compareTime(time, updateEventDao.getStart()))
//                                binding.endTimeTv2.setText(time);
//                            else {
//                                Dialogs.toast(getContext(), v, "Sell end time must be earlier than Event Start time");
//                                binding.endTimeTv2.setText(getString(R.string.end_time));
//                            }
//                        } else
//                            binding.endTimeTv2.setText(time);
//                    else {
//                        Dialogs.toast(getContext(), v, "Start time must be earlier than End time");
//                        binding.endTimeTv2.setText(getString(R.string.end_time));
//                    }
//                }
            });
    }

    private void moveItem(int oldPos, int newPos) {
        if (previousImages.size() > 0) {
            ImageDAO temp = previousImages.get(oldPos);
            previousImages.set(oldPos, previousImages.get(newPos));
            previousImages.set(newPos, temp);
            galleryPicAdapter.notifyItemChanged(oldPos);
            galleryPicAdapter.notifyItemChanged(newPos);
        } else if (imageDaoList.size() > 0) {
            ImageDAO temp = imageDaoList.get(oldPos);
            imageDaoList.set(oldPos, imageDaoList.get(newPos));
            imageDaoList.set(newPos, temp);
            galleryPicAdapter.notifyItemChanged(oldPos);
            galleryPicAdapter.notifyItemChanged(newPos);
        }
    }

    private void confirmPaidFreeDialog(View V) {

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View view = LayoutInflater.from(activity).inflate(R.layout.dialog_confirm_paid_free, null);

        TextView tvNext = (TextView) view.findViewById(R.id.tvNextBtn);
        ImageView ivClose = (ImageView) view.findViewById(R.id.ivClose);
        RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.radioGrpFreePaid);
        RadioButton radioBtnYes = (RadioButton) view.findViewById(R.id.radioBtnYes);
        RadioButton radioBtnNo = (RadioButton) view.findViewById(R.id.radioBtnNo);

        eventType = "Free";

        imageList = new ArrayList<>();
        for (ImageDAO imageDAO : createEventDAO.getImageDAOList()) {
            imageList.add(imageDAO.getVenueImages());
        }


        tvNext.setOnClickListener(v -> {

            if (eventType == null || eventType.equals("")) {
                Toast.makeText(activity, "Please select yes or no", Toast.LENGTH_SHORT).show();
                return;
            }
            if (eventType.equals("Paid")) {
                createEventDAO.setPaidType(eventType);
                alertDialog.dismiss();

                postEvent(V);
            } else if (eventType.equals("Free")) {
                createEventDAO.setPaidType(eventType);
                alertDialog.dismiss();

                CreateEventDetailsPostRequest();

//                Navigation.findNavController(V).navigate(
//                        CreateEventFragmentDirections.actionCreateEventFragmentToCreateEventFullEvent()
//                                .setEventDAO(createEventDAO));
            }
        });

        ivClose.setOnClickListener(v -> {
            alertDialog.dismiss();
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.radioBtnYes) {
                    eventType = "Free";
                } else {
                    eventType = "Paid";
                }
            }
        });


        builder.setView(view);
        alertDialog = builder.create();
        if (alertDialog.getWindow() != null)
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }

    private void postEvent(View v) {

        createEventDAO.setHelplineNumber(null);
        createEventDAO.setTicketInfoWhenTicketsNotSelected(null);

        BottomSheetDialog dialog = new BottomSheetDialog(mContext, R.style.BottomSheetDialog);
        eventDialogBinding = DataBindingUtil.inflate(LayoutInflater.from(mContext), R.layout.layout_post_event_dialog, null, false);
        dialog.setContentView(eventDialogBinding.getRoot());
        dialog.show();

        eventDialogBinding.cbAutoFill.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    getHostDetail();
                }
            }
        });

        eventDialogBinding.tvConfirmBtn.setOnClickListener(v1 -> {
            String mobileNumber = eventDialogBinding.etMobileNumber.getText().toString().trim();
            String address = eventDialogBinding.etAddress.getText().toString().trim();
            String website = eventDialogBinding.etWebsite.getText().toString().trim();

            if (mobileNumber.length() == 0) {
                Toast.makeText(mContext, "Please enter mobile number", Toast.LENGTH_LONG).show();
                return;
            }
            if (address.length() == 0) {
                Toast.makeText(mContext, "Please enter your address", Toast.LENGTH_LONG).show();
                return;
            }
             /*if (mobileNumber.length() < 0 ) {
                Toast.makeText(mContext, getString(R.string.invalidPhoneNumber), Toast.LENGTH_LONG).show();
                return;
            }*/

           /* if (TextUtils.isEmpty(info)) {
                Toast.makeText(mContext, getString(R.string.ticketDescOrPhone), Toast.LENGTH_LONG).show();
                return;
            }

            createEventDAO.setTicketInfoWhenTicketsNotSelected(info);*/

            createEventDAO.setHostMobile(mobileNumber);
            createEventDAO.setHostAddress(address);
            createEventDAO.setWebsiteUrl(website);

            dialog.dismiss();

            Navigation.findNavController(v).navigate(
                    CreateEventFragmentDirections.actionCreateEventFragmentToMinPaymentFragment().setEventDAO(createEventDAO));


        });
        eventDialogBinding.ivClose.setOnClickListener(v1 -> {
            dialog.dismiss();
        });

    }

    private void getHostDetail() {
        loader.show("");

        Call call = apiInterface.getHostDetail();

        call.enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                loader.dismiss();

                Log.e("got result", "yes");
                Log.e("got result", "getHost response> " + response);

                if (response.isSuccessful()) {

                    HostDetailResponse hostDetailResponse = new HostDetailResponse();

                    if (response.isSuccessful()) {
                        hostDetailResponse.setSuccess(true);
                        hostDetailResponse.setCode(response.code());
                        try {
                            JSONObject OBJ = new JSONObject(response.body().toString());
                            Log.e("got result", "getHost response> " + OBJ.toString());
                            Gson gson = new Gson();
                            hostDetailResponse = gson.fromJson(OBJ.toString(), HostDetailResponse.class);

                            if (hostDetailResponse.getData().getHostMobile() != null) {
                                eventDialogBinding.etMobileNumber.setText(hostDetailResponse.getData().getHostMobile());
                            } else {
                                Toast.makeText(getActivity(), "Previous data not available.", Toast.LENGTH_SHORT).show();
                            }
                            if (hostDetailResponse.getData().getHostAddress() != null) {
                                eventDialogBinding.etAddress.setText(hostDetailResponse.getData().getHostAddress());
                            }
                            if (hostDetailResponse.getData().getWebsiteUrl() != null) {
                                eventDialogBinding.etWebsite.setText(hostDetailResponse.getData().getWebsiteUrl());
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        try {
                            hostDetailResponse.setCode(response.code());
                            JSONObject OBJ = new JSONObject(response.errorBody().string());
                            hostDetailResponse.setSuccess(OBJ.getBoolean(API.SUCCESS));
                            hostDetailResponse.setMessage(OBJ.getString(API.MESSAGE));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                } else {
                    Dialogs.toast(getContext(), binding.getRoot(), "Something went wrong!");
                }

            }

            @Override
            public void onFailure(Call call, Throwable t) {
                t.printStackTrace();
                loader.dismiss();
                Dialogs.toast(getContext(), binding.getRoot(), "Something went wrong!");
            }
        });
    }

    private void CreateEventDetailsPostRequest() {
        loader.show("");
        RequestBody eventType = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getEventType()));
        RequestBody categoryId = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getCategoryId()));

        RequestBody paymentId = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getPaymentId()));
        RequestBody hostMobile = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getHostMobile()));
        RequestBody hostAddress = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getHostAddress()));
        RequestBody websiteUrl = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getWebsiteUrl()));

        RequestBody subCategoryId = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getSubCategoryId());
        RequestBody name = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getName());
        RequestBody eventOccurrenceType = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getEventOccuranceType());
        JsonArray occorArray;
        if (createEventDAO.getOccurredOn().length() > 0) {
            String[] arr = createEventDAO.getOccurredOn().substring(1, createEventDAO.getOccurredOn().length() - 1).split(",");
            Log.d("fmkalsm", "CreateEventDetailsPostRequest: " + arr.toString());
            occorArray = new JsonArray(arr.length);
            for (String s : arr) occorArray.add(Integer.valueOf(s));
        } else {
            occorArray = new JsonArray(1);
            occorArray.add(0);
        }

        RequestBody eventOccuranceOn = RequestBody.create(MediaType.parse("multipart/form-data"), occorArray.toString());
        RequestBody startDate = null;
        RequestBody endDate = null;

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
            Date startDateUtil = sdf.parse(createEventDAO.getStartDate() + " " + createEventDAO.getStartTime());
            startDate = RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(startDateUtil));
//           startDate = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getStartDate() + " " + createEventDAO.getStartTime());

            Date endDateUtil = sdf.parse(createEventDAO.getEndDate() + " " + createEventDAO.getEndTime());
//            endDate = RequestBody.create(MediaType.parse("multipart/form-data"), isoSDF.format(endDateUtil));
            endDate = RequestBody.create(MediaType.parse("multipart/form-data"), Utility.localToUTC(endDateUtil));
//            endDate = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getEndDate() + " " + createEventDAO.getEndTime());
        } catch (Exception e) {
            e.printStackTrace();
        }

        RequestBody description = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getDesc());
        RequestBody description2 = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getDesc2());
        RequestBody paidType = RequestBody.create(MediaType.parse("multipart/form-data"), createEventDAO.getPaidType());

        RequestBody ticketInfoURL = null, helpLine = null;
        RequestBody sellingStartDate = null, sellingEndDate = null;
//        RequestBody willEventAvailableRequestBody = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(willEventAvailable));


        JsonArray free = null;
        JsonArray paidTicket = null;
        JsonArray paidSeat = null;
        JsonArray vipTicket = null;
        JsonArray vipSeat = null;

        String helplineNumber = createEventDAO.getHelplineNumber();
        String info = createEventDAO.getTicketInfoWhenTicketsNotSelected();

        if (info != null || helplineNumber != null) {
            if (info != null)
                ticketInfoURL = RequestBody.create(MediaType.parse("multipart/form-data"), info);
            if (helplineNumber != null)
                helpLine = RequestBody.create(MediaType.parse("multipart/form-data"), helplineNumber);

        } else {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.ENGLISH);
                Date startDateUtil = sdf.parse(createEventDAO.getSellStartDate() + " " + createEventDAO.getSellStartTime());
                sellingStartDate = RequestBody.create(MediaType.parse("multipart/form-data"), startDateUtil.toString());
                Date endDateUtil = sdf.parse(createEventDAO.getSellEndDate() + " " + createEventDAO.getSellEndTime());
                sellingEndDate = RequestBody.create(MediaType.parse("multipart/form-data"), endDateUtil.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (createEventDAO.isFreeTicketEnabled() == 1 && createEventDAO.getFreeTicketDaoList() != null && createEventDAO.getFreeTicketDaoList().size() > 0) {
                free = new JsonArray(createEventDAO.getFreeTicketDaoList().size());
                for (FreeTicketDao dao : createEventDAO.getFreeTicketDaoList()) {
                    JsonObject object = new JsonObject();
                    object.addProperty("ticketName", StringUtils.capitalizeWord(dao.getTicketName()));
                    object.addProperty("totalQuantity", dao.getTotalTicketsQuantity());
                    object.addProperty("description", dao.getDesc().trim());
                    free.add(object);
                }
            }

            if (createEventDAO.isRSVPTicketEnabled() == 1 && createEventDAO.getRsvpTicketDaoList() != null && createEventDAO.getRsvpTicketDaoList().size() > 0) {
                paidTicket = new JsonArray(createEventDAO.getRsvpTicketDaoList().size());

                for (RSVPTicketDao dao : createEventDAO.getRsvpTicketDaoList()) {
                    JsonObject object = new JsonObject();
                    object.addProperty("ticketName", dao.getTicketName());
                    object.addProperty("totalQuantity", dao.getTotalTicketsQuantity());
                    object.addProperty("description", dao.getDesc().trim());
                    object.addProperty("pricePerTicket", dao.getPriceTicket());
                    paidTicket.add(object);
                }
            }


            if (createEventDAO.isVIPTicketEnabled() == 1 && createEventDAO.getVipTicketDaoList() != null && createEventDAO.getVipTicketDaoList().size() > 0) {
                vipTicket = new JsonArray(createEventDAO.getVipTicketDaoList().size());

                for (RSVPTicketDao dao : createEventDAO.getVipTicketDaoList()) {
                    JsonObject object = new JsonObject();
                    object.addProperty("ticketName", dao.getTicketName());
                    object.addProperty("totalQuantity", dao.getTotalTicketsQuantity());
                    object.addProperty("description", dao.getDesc().trim());
                    object.addProperty("pricePerTicket", dao.getPriceTicket());
                    vipTicket.add(object);
                }
            }


            if (createEventDAO.isVipSeatEnabled() == 1 && createEventDAO.getVipTableAndSeatingDaos() != null && createEventDAO.getVipTableAndSeatingDaos().size() > 0) {
                vipSeat = new JsonArray(createEventDAO.getVipTableAndSeatingDaos().size());

                for (TableAndSeatingDao dao : createEventDAO.getVipTableAndSeatingDaos()) {
                    JsonObject object = new JsonObject();
                    object.addProperty("ticketName", dao.getCategoryName());
                    object.addProperty("noOfTables", dao.getNoOfTables());
                    object.addProperty("totalQuantity", dao.getNoOfTables());
                    object.addProperty("personPerTable", dao.getPersonPerTable());
                    object.addProperty("pricePerTable", dao.getPricePerTable());
                    object.addProperty("pricePerTicket", dao.getPricePerTable() / dao.getPersonPerTable());
                    object.addProperty("description", dao.getDesc().trim());
                    vipSeat.add(object);
                }
            }

            if (createEventDAO.isRSVPSeatEnabled() == 1 && createEventDAO.getRsvpTableAndSeatingDaos() != null && createEventDAO.getRsvpTableAndSeatingDaos().size() > 0) {
                paidSeat = new JsonArray(createEventDAO.getRsvpTableAndSeatingDaos().size());

                for (TableAndSeatingDao dao : createEventDAO.getRsvpTableAndSeatingDaos()) {
                    JsonObject object = new JsonObject();
                    object.addProperty("ticketName", dao.getCategoryName());
                    object.addProperty("noOfTables", dao.getNoOfTables());
                    object.addProperty("totalQuantity", dao.getNoOfTables());
                    object.addProperty("personPerTable", dao.getPersonPerTable());
                    object.addProperty("pricePerTable", dao.getPricePerTable());
                    object.addProperty("pricePerTicket", dao.getPricePerTable() / dao.getPersonPerTable());
                    object.addProperty("description", dao.getDesc().trim());
                    paidSeat.add(object);
                }
            }
        }

        RequestBody venueAddress = null, venueLat = null, venueLongt = null, veneuName = null, venueId = null, countryCode = null, cityName = null, subVenue = null;

        if (createEventDAO.getLat() == null) {
            venueId = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getVenueId()));
            if (createEventDAO.getSelectedSubVenues() != null && createEventDAO.getSelectedSubVenues().size() > 0) {
                JsonArray jsonArray = new JsonArray();
                for (int i = 0; i < createEventDAO.getSelectedSubVenues().size(); i++) {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("venueId", createEventDAO.getSelectedSubVenues().get(i).getVenueId());
                    jsonObject.addProperty("subVenueId", createEventDAO.getSelectedSubVenues().get(i).getSubVenueId());
                    jsonObject.addProperty("status", createEventDAO.getSelectedSubVenues().get(i).getStatus());
                    jsonArray.add(jsonObject);
                }
                subVenue = RequestBody.create(MediaType.parse("multipart/form-data"), jsonArray.toString());
            }
        } else {
            veneuName = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getVenueName()));
            venueAddress = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getVenueAddress()));
            venueLat = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getLat()));
            venueLongt = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getLongt()));
            cityName = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getCityName()));
            countryCode = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(createEventDAO.getCountryCode()));
        }

        RequestBody freeJsonBody = null;
        if (free != null)
            freeJsonBody = RequestBody.create(MediaType.parse("multipart/form-data"), free.toString());

        RequestBody vipTicketBody = null;
        if (vipTicket != null)
            vipTicketBody = RequestBody.create(MediaType.parse("multipart/form-data"), vipTicket.toString());

        RequestBody vipSeatingBody = null;
        if (vipSeat != null)
            vipSeatingBody = RequestBody.create(MediaType.parse("multipart/form-data"), vipSeat.toString());

        RequestBody paidTicketBody = null;
        if (paidTicket != null)
            paidTicketBody = RequestBody.create(MediaType.parse("multipart/form-data"), paidTicket.toString());

        RequestBody paidSeatBody = null;
        if (paidSeat != null)
            paidSeatBody = RequestBody.create(MediaType.parse("multipart/form-data"), paidSeat.toString());

        MultipartBody.Part[] image = null;
        if (imageList.size() > 0) {
            image = new MultipartBody.Part[imageList.size()];
            try {
                for (int index = 0; index < imageList.size(); index++) {
                    File file = new File(imageList.get(index));
                    Log.e("What i am uploading!", file.toString());
                    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
                    MultipartBody.Part fileToUploadPart = MultipartBody.Part.createFormData("images", file.getName(), requestFile);
                    image[index] = fileToUploadPart;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Call call;

        if (createEventDAO.getPaidType().equals("Paid")) {
            RequestBody isEventPaid = RequestBody.create(MediaType.parse("multipart/form-data"), "1");
            call = apiInterface.postEventPaid(eventType,
                    categoryId, subCategoryId,
                    name,
                    eventOccurrenceType, eventOccuranceOn,
                    startDate, endDate,
                    venueId, veneuName, venueAddress,
                    venueLat, venueLongt,
                    countryCode,
                    cityName,
                    description,
                    description2,
                    paidType,
                    vipTicketBody, vipSeatingBody, paidTicketBody, paidSeatBody, freeJsonBody, ticketInfoURL, helpLine, sellingStartDate, sellingEndDate,

                    // new parameters
                    paymentId,
                    hostMobile,
                    hostAddress,
                    websiteUrl,
                    isEventPaid,
                    subVenue,
                    image);

        } else {

            RequestBody isEventPaid = RequestBody.create(MediaType.parse("multipart/form-data"), "0");

            call = apiInterface.postEventFree(eventType,
                    categoryId, subCategoryId,
                    name,
                    eventOccurrenceType, eventOccuranceOn,
                    startDate, endDate,
                    venueId, veneuName, venueAddress,
                    venueLat, venueLongt,
                    countryCode,
                    cityName,
                    description,
                    description2,
                    paidType,
                    vipTicketBody, vipSeatingBody, paidTicketBody, paidSeatBody, freeJsonBody, ticketInfoURL, helpLine, sellingStartDate, sellingEndDate, isEventPaid,
                    subVenue,
                    image);

        }


        call.enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                loader.dismiss();
                if (response.isSuccessful()) {
                    String msg = "";
                    try {
                        msg = new JSONObject(response.body().toString()).getString("message");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Utility.setSharedPreferencesBoolean(getContext(), API.HOT_RELOAD, true);
                    Utility.setSharedPreferencesBoolean(getContext(), API.HOT_RELOAD_EVENTS, true);

                    App.createEventDAO = null;

                    Dialogs.showActionDialog(getContext(),
                            getString(R.string.app_name),
                            msg,
                            "Done",
                            v1 -> getActivity().finish()
                    );

                } else {
                    Dialogs.toast(getContext(), binding.getRoot(), "Something went wrong!");
                }

            }

            @Override
            public void onFailure(Call call, Throwable t) {
                t.printStackTrace();
                loader.dismiss();
                Dialogs.toast(getContext(), binding.getRoot(), "Something went wrong!");
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        setData();
    }

    private void setData() {
        try {

            selection = new StringBuilder();

            startDate = binding.textView39.getText().toString();
            endDate = binding.endDateTv.getText().toString();
            startTime = binding.startTimeTv.getText().toString();
            endTime = binding.endTimeTv.getText().toString();

            String name = binding.eventNameEt.getText().toString().trim();
            String selectedAvailability = binding.typeSubSpinner.getText().toString();


            if (eventOccuranceType.equals("daily")) {
                String sarr[] = selectedAvailability.split(", ");
                for (int i = 0; i < sarr.length; i++) {
                    if (i == 0) {
                        selection.append("[").append(StringUtils.getDayMonthNum(sarr[i]) + "");
                    } else
                        selection.append(",").append(StringUtils.getDayMonthNum(sarr[i]) + "");

                    if ((i + 1) == sarr.length)
                        selection.append("]");
                }
            }
            if (eventOccuranceType.equals("monthly")) {
                String sarr[] = selectedAvailability.split(", ");
                for (int i = 0; i < sarr.length; i++) {
                    if (i == 0) {
                        selection.append("[").append(sarr[i]);
                    } else
                        selection.append(",").append(sarr[i]);

                    if ((i + 1) == sarr.length)
                        selection.append("]");
                }
            }

            if (eventOccuranceType.equals("weekly")) {
                switch (selectedAvailability) {
                    case "Sunday":
                        selection.append("[0]");
                        break;
                    case "Monday":
                        selection.append("[1]");
                        break;
                    case "Tuesday":
                        selection.append("[2]");
                        break;
                    case "Wednesday":
                        selection.append("[3]");
                        break;
                    case "Thursday":
                        selection.append("[4]");
                        break;
                    case "Friday":
                        selection.append("[5]");
                        break;
                    case "Saturday":
                        selection.append("[6]");
                        break;
                }
            }

            venueName = binding.venueLocEt.getText().toString().trim();
            String additionalInfo = binding.additionEt.getText().toString().trim();
            String additionalInfo2 = binding.additionEt2.getText().toString().trim();

            createEventDAO.setName(name);
            createEventDAO.setEventOccuranceType(eventOccuranceType);
            createEventDAO.setOccurredOn(selection.toString());

            createEventDAO.setStartDate(startDate);
            createEventDAO.setEndDate(endDate);
            createEventDAO.setStartTime(startTime);
            createEventDAO.setEndTime(endTime);

//            if (latLongt != null) {
            createEventDAO.setVenueName(venueName);
//                createEventDAO.setLat(String.valueOf(latLongt.latitude));
//                createEventDAO.setLongt(String.valueOf(latLongt.longitude));
//            }

            createEventDAO.setDesc(additionalInfo);
            createEventDAO.setDesc2(additionalInfo2);
//            createEventDAO.setVenueAddress(binding.venueLocEt.getText().toString().trim());
            createEventDAO.setPaidType(eventType);
            createEventDAO.setImageList(imageList);
            createEventDAO.setImageDAOList(imageDaoList);

            if (App.createEventDAO != null) {
                App.createEventDAO = createEventDAO;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
