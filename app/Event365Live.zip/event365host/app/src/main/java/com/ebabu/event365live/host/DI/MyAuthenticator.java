package com.ebabu.event365live.host.DI;

import android.content.Context;

import com.ebabu.event365live.host.api.API;
import com.ebabu.event365live.host.utils.Utility;

import java.io.IOException;

import okhttp3.Authenticator;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;

public class MyAuthenticator implements Authenticator{

    Context context;

    public MyAuthenticator(Context context) {
        this.context = context;
    }

    @Override
    public Request authenticate(Route route, Response response) throws IOException {
        return response.request().newBuilder()
                .addHeader("Authorization", "Bearer " + Utility.getSharedPreferencesString(context, API.AUTHORIZATION))
                .build();
    }
}
