package com.ebabu.event365live.host;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ebabu.event365live.host.DI.App;
import com.ebabu.event365live.host.api.ApiInterface;
import com.ebabu.event365live.host.bankdetails.adapter.TransactionHistoryVPAdapter;
import com.ebabu.event365live.host.bankdetails.fragment.CompletedPaymentFrag;
import com.ebabu.event365live.host.bankdetails.fragment.PendingHistoryFrag;
import com.ebabu.event365live.host.bankdetails.modal.TransactionHistoryModal;
import com.ebabu.event365live.host.databinding.FragmentTransactionHistoryBinding;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class TransactionHistoryFragment extends Fragment {
    private TransactionHistoryVPAdapter adapter;
    private FragmentTransactionHistoryBinding historyBinding;
    public static boolean isFromSuccessWithdraw;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(getArguments() != null){
           isFromSuccessWithdraw = getArguments().getBoolean("isFromSuccessWithdraw",false);
        }
    }

    public TransactionHistoryFragment() {
        // Required empty public constructor

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        historyBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_transaction_history, container, false);
        setupViewPager();
        historyBinding.ivBackBtn.setOnClickListener(v->getActivity().onBackPressed());
        return historyBinding.getRoot();
    }

    private void setupViewPager(){
        adapter = new TransactionHistoryVPAdapter(getChildFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adapter.addFrag(new PendingHistoryFrag());
        adapter.addFrag(new CompletedPaymentFrag());
        historyBinding.transactionHistoryVP.setAdapter(adapter);
        historyBinding.transactionHistoryTL.setupWithViewPager(historyBinding.transactionHistoryVP);
        if(isFromSuccessWithdraw) historyBinding.transactionHistoryVP.setCurrentItem(1,true);
    }



}
