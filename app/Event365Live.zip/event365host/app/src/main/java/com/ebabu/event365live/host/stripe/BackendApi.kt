package com.ebabu.event365live.stripe

import com.ebabu.event365live.host.api.API
import com.google.gson.JsonObject
import io.reactivex.Observable
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface BackendApi {

    @POST("GetEphemeralKey")
    fun createEphemeralKey(@Header(API.AUTHORIZATION) auth: String, @Body json: JsonObject): Observable<ResponseBody>
}