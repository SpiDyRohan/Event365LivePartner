package com.ebabu.event365live.host.bouncerecycler;

public class SimpleSpringListener implements SpringListener {
    public SimpleSpringListener() {
    }

    public void onSpringUpdate(Spring spring) {
    }

    public void onSpringAtRest(Spring spring) {
    }

    public void onSpringActivate(Spring spring) {
    }

    public void onSpringEndStateChange(Spring spring) {
    }
}
